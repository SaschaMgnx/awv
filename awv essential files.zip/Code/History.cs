﻿using System.Collections.Generic;

namespace awv {


    public class HistorySocial  {

        public enum _tobaccoKind {
            na, Cigarettes = 23, Pipe = 24, Cigar = 25, Chew = 26
        }

        public enum _homeEnvir {
            na = -1, PrivateHome = 0, AssistedLiving = 1, Other = 2
        }

        public bool? TobaccoEverUsed { get; set; }

        public List<_tobaccoKind> TobaccoKind{ get; set;}

        public int? TobaccoTimesPerWeek { get; set; }



        public bool? AlcoholUse { get; set; }

        public int? AlcoholTimesPerWeek { get; set; }




        public bool? RecDrugsUse { get; set; }

        public string RecDrugsTypes { get; set; }



        public bool? Exercise { get; set; }

        public int? ExerciseTimesPerWeek { get; set; }

        public string ExerciseTypes { get; set; }




        public bool? SpecialDiet { get; set; }

        public string SpecialDietReason { get; set; }



        public bool? AlwaysBuckledUp { get; set; }



        public bool? SunscreenWorn { get; set; }


        public bool? ProblemsDressFeed { get; set; }


        public bool? NeedHelpShopping { get; set; }

        public string Occupation { get; set; }



        public _homeEnvir HomeEnvironment { get; set; }

        public string HomeEnvironmentOther { get; set; }

    }


    public class HistoryFamily {


        //insert into[dbo].[OptionsLookup] values(0,'na','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(1,'Self','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(2,'Father','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(3,'Mother','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(4,'Sisters','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(5,'Brothers','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(6,'Aunts','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(7,'Uncles','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(8,'Sons','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(9,'Daughters','FamilyMembers')
        //insert into[dbo].[OptionsLookup] values(10,'Deceased','Disease')
        //insert into[dbo].[OptionsLookup] values(11,'Hypertension','Disease')
        //insert into[dbo].[OptionsLookup] values(12,'HeartDisease','Disease')
        //insert into[dbo].[OptionsLookup] values(13,'Stroke','Disease')
        //insert into[dbo].[OptionsLookup] values(14,'KideneyDisease','Disease')
        //insert into[dbo].[OptionsLookup] values(15,'GeneticDisorder','Disease')
        //insert into[dbo].[OptionsLookup] values(16,'Alcoholism','Disease')
        //insert into[dbo].[OptionsLookup] values(17,'LiverDisease','Disease')
        //insert into[dbo].[OptionsLookup] values(18,'Depression','Disease')
        //insert into[dbo].[OptionsLookup] values(19,'ColonOrRectalCancer','Disease')
        //insert into[dbo].[OptionsLookup] values(20,'BreastCancer','Disease')
        //insert into[dbo].[OptionsLookup] values(21,'OtherCancer','Disease')

        //public enum FamilyMembers { na, Self, Father, Mother, Sisters, Brothers, Aunts, Uncles, Sons, Daughters }
        //public FamilyMembers Deceased { get; set; }
        //public FamilyMembers Hypertension { get; set; }
        //public FamilyMembers HeartDisease { get; set; }
        //public FamilyMembers Stroke { get; set; }
        //public FamilyMembers KideneyDisease { get; set; }
        //public FamilyMembers GeneticDisorder { get; set; }
        //public FamilyMembers Alcoholism { get; set; }
        //public FamilyMembers LiverDisease { get; set; }
        //public FamilyMembers Depression { get; set; }
        //public FamilyMembers ColonOrRectalCancer { get; set; }
        //public FamilyMembers BreastCancer { get; set; }
        //public FamilyMembers OtherCancer { get; set; }

        public HistoryFamily( int familyMemberIndex, int diseaseIndex) {
            FamilyMember = familyMemberIndex;
            Disease = diseaseIndex;
        }

        public int FamilyMember { get; set; }
        public int Disease { get; set; }


    }

}