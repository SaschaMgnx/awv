﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace awv
{
    public class HospitalVisit
    {
        public HospitalVisit() { }
        public HospitalVisit(string reason, string facility, string physician, DateTime visitDate)
        {
            Reason = reason; Facility = facility; Physician = physician; VisitDate = visitDate;
        }
        public string Reason { get; set; }
        public string Facility { get; set; }
        public string Physician { get; set; }
        public DateTime? VisitDate { get; set; }

    }
}