﻿using Aspose.Html;
using Aspose.Html.Rendering;
using Aspose.Html.Rendering.Pdf;
using Aspose.Pdf;
using System;
using System.IO;
using System.Net;
using System.Text;

namespace awv
{
    public partial class _3 : System.Web.UI.Page {

        protected void Page_Load(object sender, EventArgs e) { 

        }

        private static void aspx2Pdf( string path) {




            // Create a request for the URL.
            var request = WebRequest.Create("http://localhost:49441/Patients.aspx"); //"https://En.wikipedia.org/wiki/Main_Page"

            // If required by the server, set the credentials.
            request.Credentials = CredentialCache.DefaultCredentials;

            // Time out in miliseconds before the request times out
            // Request.Timeout = 100;


            // Get the response.
            var response = (HttpWebResponse)request.GetResponse();

            // Get the stream containing content returned by the server.
            var dataStream = response.GetResponseStream();

            // Open the stream using a StreamReader for easy access.
            var reader = new StreamReader(dataStream);

            // Read the content.
            string responseFromServer = reader.ReadToEnd();

            reader.Close();
            dataStream.Close();
            response.Close();

            var stream = new MemoryStream( Encoding.UTF8.GetBytes( responseFromServer));
            var options = new HtmlLoadOptions("http://localhost:49441/"); //https://En.wikipedia.org/wiki/

            // Load HTML file
            var pdfDocument = new Document(stream, options);

            options.PageInfo.IsLandscape = true;

            // Save output as PDF format
            pdfDocument.Save( @"C:\Users\Alexander\Desktop\test_Aspx2Pdf.pdf");

        }

        protected void Button1_Click(object sender, EventArgs e) {

            string dataDir = Server.MapPath("") + @"\\Temp\";
            renderPdf( dataDir + "2018_3_11_16_3_33.pdf");

        }








        private void createPdf() {
            string dataDir = Server.MapPath("") + @"\\Temp\";
            var InputHtml = dataDir + "input.html";
            using (var fs = File.Create(InputHtml))
            using (var sw = new StreamWriter(fs)) {
                sw.Write(
                @"<style>
                .st
                { color: green; }
                </style>
                <br/><br/><br/><br/><br/><br/>
                <div id=id1>Aspose.Html rendering Text in Black Color</div>
                <div id=id2 class='st'>Aspose.Html rendering Text in Green Color</div>
                <div id=id3 class='st' style='color: blue;'>Aspose.Html rendering Text in Blue Color</div>
                <div id=id3 class='st' style='color: red;'><font face='Arial'>Aspose.Html rendering Text in Red Color</font></div>");
            }

            var Resultant_output = dataDir +
                    DateTime.Now.Year.ToString() + "_" +
                    DateTime.Now.Month.ToString() + "_" +
                    DateTime.Now.Day.ToString() + "_" +
                    DateTime.Now.Hour.ToString() + "_" +
                    DateTime.Now.Minute.ToString() + "_" +
                    DateTime.Now.Second.ToString() + ".pdf";

            // Create PdfRendering Options object
            var pdf_options = new PdfRenderingOptions();

            // The PageSetup also provides different properties i.e. FirstPage, LastPage, LeftPage, RightPage and they are used to setup (PageSize, Margin) for every page.
            // In most cases, usage of setup any page is enough, but in some complicated cases, you may need to fine tune page settings. It can be done either by CSS styles or by using rendering options.
            // the size for drawing is in pixels
            pdf_options.PageSetup.AnyPage = new Aspose.Html.Drawing.Page(new Aspose.Html.Drawing.Size(400, 100));

            // Instantiate PdfDevice object while passing PdfRenderingOptions and resultant file path as arguments
            using (var pdf_device = new PdfDevice(pdf_options, Resultant_output))

            // Create HtmlRenderer object
            using (var renderer = new HtmlRenderer())

            // Create HtmlDocument instance while passing path of already created HTML file
            using (var html_document = new HTMLDocument(InputHtml)) {
                // Render the output using HtmlRenderer
                renderer.Render( pdf_device, html_document);
            }
        }


        protected void renderPdf( string sFile) {
            var docSize = new FileInfo( sFile).Length;
            Response.ClearContent();
            Response.ContentType = "application/pdf";
            Response.AddHeader( "Content-Disposition", "inline; filename=" + sFile);
            Response.AddHeader( "Content-Length", docSize.ToString());
            Response.BinaryWrite( File.ReadAllBytes( sFile));
            Response.End();
        }

        protected void renderPdf( string fName, byte[] byteContent) {
            var fi = new FileInfo( fName);
            string fExtension = fi.Extension;
            Response.ContentType = "application/pdf";
            Response.AppendHeader( "Content-Disposition", "inline; filename=" + fName);
            Response.BinaryWrite( byteContent);
            Response.End();
        }




    }
}