﻿
using System;

namespace awv {

    public static class Common {

        public static string Frequency( int? optionLookupIndex) {
            var frequencyListing = new Lookup("Frequency").Listing;
            foreach ( var item in frequencyListing) {   
                if ( item.Key.Equals( optionLookupIndex)) {
                    return item.Value;
                }
            }
            return string.Empty;
        }


        public static double? GetNullableDouble(string d) {
            if (!string.IsNullOrEmpty(d)) {
                double res;
                if (double.TryParse(d, out res)) {
                    return res;
                }
            }
            return null;
        }
        public static bool? GetNullableBool(string v)  {
            if (!string.IsNullOrEmpty(v)) {
                if (v.ToUpper().Equals("TRUE")) {
                    return true;
                }
                if (v.ToUpper().Equals("FALSE")) {
                    return false;
                }
            }
            return null;
        }

        public static DateTime? GetNullableDateTimeValue(string d) {
            if (!string.IsNullOrEmpty(d)) {
                DateTime res;
                if (DateTime.TryParse(d, out res)) {
                    return res;
                }
            }
            return null;
        }


        public static int? GetNullableInt( string d) {
            if ( !string.IsNullOrEmpty(d.Trim())) {
                int res;
                if ( int.TryParse(d.Trim(), out res)) {
                    return res;
                }
            }
            return null;
        }

        public static Int16? GetNullableInt16(string d) {
            if (!string.IsNullOrEmpty( d.Trim())) {
                Int16 res;
                if (Int16.TryParse(d.Trim(), out res)) {
                    return res;
                }
            }
            return null;
        }

    }
}