﻿using System;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace awv {

    public partial class Patients : Page {
        protected void Page_Load(object sender, EventArgs e) {
            grdPatients.HeaderRow.TableSection = TableRowSection.TableHeader;
        }

        protected void btnAddPatient_Click(object sender, EventArgs e) {
            var p = new PatientBase() {
                FName = txtPatientFName.Text.Trim(),
                LName = txtPatientLName.Text.Trim(),
                MName = txtPatientMName.Text.Trim(),
            };
            if (!(txtPatientFName.Text.Trim().Length + txtPatientLName.Text.Trim().Length).Equals(0)) {
                var id = new Patient().SaveDemographic(p);
                Response.Redirect("Wiz.aspx?patientid=" + id);
            } else {
                ScriptManager.RegisterStartupScript( this, this.GetType(), "scrptNoDups", "toastr.options.preventDuplicates = true;", true);
            }
        }

    }
}