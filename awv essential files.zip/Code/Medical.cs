﻿using System.Collections.Generic;

namespace awv {

    public class Medical {

        public bool Allergies { get; set; }

        public List<Allergy> AllergyList { get; set; }


        //hospital visits
        public bool VisitedHospitalSinceLastOfficeVisit { get; set; }

        public List<HospitalVisit> HospitalVisits { get; set; }



        //medications
        public bool CurrentlyTakingMedications { get; set; }

        public List<Medication> Medications { get; set; }


        // Other Providers
        public bool CurrentlySeeingOtherProviders { get; set; }

        public List<Provider> OtherProviders { get; set; }

    }

    //public class Provider {
    //    public string NameAndSpecialty { get; set; }
    //    public string TypeOfCare { get; set; }
    //    public DateTime? DateEnded { get; set; }
    //}

    //public class Medication {
    //    public string Name { get; set; }

    //    public string Frequency { get; set; }

    //    public DateTime? DateStarted { get; set; }

    //    public DateTime? DateEnded { get; set; }
    //}

    //public class HospitalVisit {
    //    public HospitalVisit(){}
    //    public HospitalVisit( string reason, string facility, string physician, DateTime visitDate) {
    //        Reason = reason; Facility = facility; Physician = physician; VisitDate = visitDate;
    //    }
    //    public string Reason { get; set; }
    //    public string Facility { get; set; }
    //    public string Physician { get; set; }
    //    public DateTime? VisitDate { get; set; }

    //}

    //public class Allergy {

    //    public Allergy(string descr, string reaction) {
    //        Descr = descr;
    //        Reaction = reaction;
    //    }

    //    public string Descr { get; set; }

    //    public string Reaction { get; set; }

    //}

}