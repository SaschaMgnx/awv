﻿using System;

namespace awv {

    public class PatientBase {

        public enum _Gender {
            Male, Female
        }

        public int? OfficeId { get; set; }

        public int PatientId { get; set; }

        public string FName { get; set; }

        public string LName { get; set; }

        public string MName { get; set; }

        public DateTime? DOB { get; set; }

        public _Gender? Gender { get; set; }

        public string sGender { set; get; }

        public string FullName => LName + ", " + FName + " " + MName;

        public int? Age {
            get {
                var now = DateTime.Today;
                var dob = new DateTime();
                if (DOB != null) {
                    dob = (DateTime) DOB;
                    return now.Year - dob.Year;
                }
                return null;
            }
        }
    }

    public class PatientSearchX {

        public int PatientId { get; set; }
        public string PatientName { get; set; }
        public int? PatientAge { get; set; }
        public string PatientGender { get; set; }
    }

    //public class PatientSearch : PatientBase {

    //    public int sAge { get; set;}


    //}

}

