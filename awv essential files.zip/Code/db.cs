﻿using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Data.Sql;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;

namespace awv {

    public class db {

        private const string cnn = "cnn";

        public Hashtable GetLookupValues( string listing) {
            var ht = new Hashtable();
            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetSqlStringCommand("select * from dbo.OptionsLookup l (nolock) where l.Listing = '" + listing + "' order by [id]");
            var dataRows = _db.ExecuteDataSet(cmd).Tables[0].Rows;
            foreach ( DataRow dr in dataRows) {
                ht.Add( Convert.ToInt16( dr["id"].ToString()), dr["Descr"].ToString());
            }
            return ht;
        }

        public SortedDictionary<int, string> _GetLookupValues(string listing)  {
            var ht = new SortedDictionary<int, string>();
            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetSqlStringCommand("select * from dbo.OptionsLookup l (nolock) where l.Listing = '" + listing + "' order by OrderId");
            var dataRows = _db.ExecuteDataSet(cmd).Tables[0].Rows;
            foreach (DataRow dr in dataRows)
            {
                ht.Add(Convert.ToInt16(dr["id"].ToString()), dr["Descr"].ToString());
            }
            return ht;
        }
        internal int SavePatientBase( PatientBase p) {
            var _db = DatabaseFactory.CreateDatabase(cnn);
            DbCommand cmd;
            if ( p.PatientId.Equals(0)) {

                cmd = _db.GetStoredProcCommand("[dbo].[CreatePatientBase]");
                _db.AddInParameter(cmd, "@FirstName", DbType.String, p.FName);
                _db.AddInParameter(cmd, "@LastName", DbType.String, p.LName);
                _db.AddInParameter(cmd, "@MiddleInit", DbType.String, p.MName);
                _db.AddInParameter(cmd, "@DOB", DbType.Date, p.DOB);
                _db.AddInParameter(cmd, "@OfficeId", DbType.Int16, p.OfficeId);
                _db.AddOutParameter(cmd, "@PatientId", DbType.Int32, p.PatientId);
                cmd.CommandType = CommandType.StoredProcedure;
                _db.ExecuteNonQuery(cmd);
                return Convert.ToInt32(_db.GetParameterValue(cmd, "@PatientId"));

            } else {
                cmd = _db.GetStoredProcCommand("[dbo].[UpdateDemographics]");
                _db.AddInParameter(cmd, "@PatientId", DbType.Int32, p.PatientId);
                _db.AddInParameter(cmd, "@FirstName", DbType.String, p.FName);
                _db.AddInParameter(cmd, "@LastName", DbType.String, p.LName);
                _db.AddInParameter(cmd, "@MiddleInit", DbType.String, p.MName);
                _db.AddInParameter(cmd, "@DOB", DbType.Date, p.DOB);

            }
            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);

            return res; // to be qa'd
        }

        public string PatientCount() {
            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetSqlStringCommand("select * from dbo.Patient (nolock)");
            var res = _db.ExecuteDataSet(cmd);
            return  res.Tables[0].Rows.Count.ToString();
        }


        internal bool AddHospitalVisit( int patientId, string reason, string facility, string physician, DateTime? visitDate = null) {
            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("dbo.AddHospitalVisit");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@Reason", DbType.String, reason);
            _db.AddInParameter(cmd, "@Facility", DbType.String, facility);
            _db.AddInParameter(cmd, "@Physician", DbType.String, physician);
            _db.AddInParameter(cmd, "@VisitDate", DbType.DateTime, visitDate);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery( cmd);
            return res.Equals(1); // to be qa'd
        }

        internal bool AddAllergy( int patientId, string allergy, string reaction) {
            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("dbo.AddAllergy");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@Allergy", DbType.String, allergy);
            _db.AddInParameter(cmd, "@TypeOfReaction", DbType.String, reaction);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery( cmd);
            return res.Equals(1); // to be qa'd
        }

        internal bool AddProvider( int patientId, string providerNameAndSpecialty, string typeofCare, DateTime? endDate = null) {
            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("dbo.AddProvider");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@ProviderNameAndSpecialty", DbType.String, providerNameAndSpecialty);
            _db.AddInParameter(cmd, "@TypeofCare", DbType.String, typeofCare);
            _db.AddInParameter(cmd, "@EndDate", DbType.DateTime, endDate);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery( cmd);
            return res.Equals(1); // to be qa'd
        }

        internal bool UpdateVitals( Patient p) {

            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[UpdateVitals]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, p.PatientId);
            _db.AddInParameter(cmd, "@Gender", DbType.Int16, p.Gender);
            _db.AddInParameter(cmd, "@Height", DbType.Double, p.HeightInCM);
            _db.AddInParameter(cmd, "@Weight", DbType.Double, p.Weight);
            _db.AddInParameter(cmd, "@BMI", DbType.Double, p.BMI);
            _db.AddInParameter(cmd, "@Waist", DbType.Double, p.Waist);
            int? BpD = null; int? BpS = null;
            if (p.BloodPressure != null) {
                BpD = p.BloodPressure.Diastolic;
                BpS = p.BloodPressure.Systolic;
            }
            _db.AddInParameter(cmd, "@BpS", DbType.Int16, BpS);
            _db.AddInParameter(cmd, "@BpD", DbType.Int16, BpD);
            _db.AddInParameter(cmd, "@Temp", DbType.Double, p.Temp);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery( cmd);
            return res.Equals(1); // to be qa'd

        }

        internal bool UpdateScreeningMinCog(
                int patientId,
                int? WordListVersion, int? PersonAnswerA, int? PersonAnswerB, int? PersonAnswerC,
                int? ScoringWordRecall, int? ScoringClockDraw) {

            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[UpdateScreeningMiniCog]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@WordListVersion", DbType.Int16, WordListVersion);
            _db.AddInParameter(cmd, "@Answer_1", DbType.Int16, PersonAnswerA);
            _db.AddInParameter(cmd, "@Answer_2", DbType.Int16, PersonAnswerB);
            _db.AddInParameter(cmd, "@Answer_3", DbType.Int16, PersonAnswerC);
            _db.AddInParameter(cmd, "@WordRecall", DbType.Int16, ScoringWordRecall);
            _db.AddInParameter(cmd, "@ClockDraw", DbType.Int16, ScoringClockDraw);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            return res.Equals(1); // to be qa'd

        }

        internal bool UpdateHistorySocial( int patientId, HistorySocial h) {

            var _db = (SqlDatabase) DatabaseFactory.CreateDatabase(cnn);


            #region TOBACCO
            var z = h.TobaccoKind;
            var dtXRefNumbers_TVP = new DataTable("XRefNumbers_TVP");
            dtXRefNumbers_TVP.Columns.Add("id", typeof(int));
            if ( z != null) {
                foreach (int s in z) {
                    dtXRefNumbers_TVP.Rows.Add( s);
                } 
            }
            #endregion


            var cmd = _db.GetStoredProcCommand("[dbo].[UpdateHistorySocial]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@TobaccoEverUsed", DbType.Boolean, h.TobaccoEverUsed);                    
            _db.AddInParameter(cmd, "@TobaccoTimesPerWeek", DbType.Int16, h.TobaccoTimesPerWeek);       
            _db.AddInParameter(cmd, "@Alcohol", DbType.Boolean, h.AlcoholUse);            
            _db.AddInParameter(cmd, "@AlcoholPerWeek", DbType.Int16, h.AlcoholTimesPerWeek);       
            _db.AddInParameter(cmd, "@DrugsUse", DbType.Boolean, h.RecDrugsUse);            
            _db.AddInParameter(cmd, "@DrugTypes", DbType.String, h.RecDrugsTypes);         
            _db.AddInParameter(cmd, "@Exercise", DbType.Boolean, h.Exercise);              
            _db.AddInParameter(cmd, "@ExerciseTimesPerWeek", DbType.Int16, h.ExerciseTimesPerWeek);      
            _db.AddInParameter(cmd, "@ExerciseTypes", DbType.String, h.ExerciseTypes);      
            _db.AddInParameter(cmd, "@SpecialDiet", DbType.Boolean, h.SpecialDiet);  
            _db.AddInParameter(cmd, "@SpecialDietReason", DbType.String, h.SpecialDietReason);  
            _db.AddInParameter(cmd, "@UseSeatBelt", DbType.Boolean, h.AlwaysBuckledUp);  
            _db.AddInParameter(cmd, "@UseSunscreen", DbType.Boolean, h.SunscreenWorn);   
            _db.AddInParameter(cmd, "@IssuesDressingFeeding", DbType.Boolean, h.ProblemsDressFeed);    
            _db.AddInParameter(cmd, "@IssuesShoppingHousekeeping", DbType.Boolean, h.NeedHelpShopping); 
            _db.AddInParameter(cmd, "@Occupation", DbType.String, h.Occupation);            
            _db.AddInParameter(cmd, "@HomeEnvir", DbType.Int16, (int)h.HomeEnvironment);    
            _db.AddInParameter(cmd, "@HomeEnvirOther", DbType.String, h.HomeEnvironmentOther);
            _db.AddInParameter(cmd, "@TobaccoKindXRef", SqlDbType.Structured, dtXRefNumbers_TVP);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            return res.Equals(1); // to be qa'd
        }

        internal void UpdateHistoryFamily( int patientId, List<HistoryFamily> historyFamilyList) {
 
 
            #region TEMPORARY CONSTANTS - TO BE CHANGED TO LOOKUP VALUES
            //6   Aunts
            //5   Brothers
            //9   Daughters
            //2   Father
            //3   Mother
            //0   na
            //1   Self
            //4   Sisters
            //8   Sons
            //7   Uncles

            //16  Alcoholism
            //20  BreastCancer
            //19  ColonOrRectalCancer
            //10  Deceased
            //18  Depression
            //15  GeneticDisorder
            //12  HeartDisease
            //11  Hypertension
            //14  KideneyDisease
            //17  LiverDisease
            //21  OtherCancer
            //13  Stroke 
            #endregion
 

            var dtHistoryFamily = new DataTable("dtHistoryFamily");
            dtHistoryFamily.Columns.Add("FamilyMember", typeof(int));
            dtHistoryFamily.Columns.Add("Disease", typeof(int));

            foreach ( var hf in historyFamilyList) {
                dtHistoryFamily.Rows.Add( hf.FamilyMember, hf.Disease);
            }

            var _db = (SqlDatabase) DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[UpdateHistoryFamily]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@XRef", SqlDbType.Structured, dtHistoryFamily);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            //return res.Equals(1); // to be qa'd
        }


        internal bool UpdateScreeningDprssn( int patientId, bool? depressed = null, bool? littleInterest = null) {

            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[UpdateScreeningDprssn]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@Depressed", DbType.Boolean, depressed);
            _db.AddInParameter(cmd, "@LittleInterest", DbType.Boolean, littleInterest);
            //_db.AddInParameter(cmd, "@Unsteady", DbType.Boolean, s.Unsteady);
            //_db.AddInParameter(cmd, "@LivesAlone", DbType.Boolean, s.LivesAlone);
            //_db.AddInParameter(cmd, "@NeedHelpWithMeals", DbType.Boolean, s.NeedHelpWithMeals);
            //_db.AddInParameter(cmd, "@HearingDifficulties", DbType.Boolean, s.HearingDifficulties);
            //_db.AddInParameter(cmd, "@StrainedHearing", DbType.Boolean, s.StrainedHearing);
            //_db.AddInParameter(cmd, "@HallwayRugs", DbType.Boolean, s.HallwayRugs);
            //_db.AddInParameter(cmd, "@LackGrabBars", DbType.Boolean, s.LackGrabBars);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            return !res.Equals(0); // to be qa'd
        }

        internal bool UpdateScreeningFnctn( int patientId, bool? unsteady = null, bool? livesAlone = null, bool? needHelpWithMeals = null) {

            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[UpdateScreeningFnctn]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            //_db.AddInParameter(cmd, "@Depressed", DbType.Boolean, depressed);
            //_db.AddInParameter(cmd, "@LittleInterest", DbType.Boolean, littleInterest);
            _db.AddInParameter(cmd, "@Unsteady", DbType.Boolean, unsteady);
            _db.AddInParameter(cmd, "@LivesAlone", DbType.Boolean, livesAlone);
            _db.AddInParameter(cmd, "@NeedHelpWithMeals", DbType.Boolean, needHelpWithMeals);
            //_db.AddInParameter(cmd, "@HearingDifficulties", DbType.Boolean, s.HearingDifficulties);
            //_db.AddInParameter(cmd, "@StrainedHearing", DbType.Boolean, s.StrainedHearing);
            //_db.AddInParameter(cmd, "@HallwayRugs", DbType.Boolean, s.HallwayRugs);
            //_db.AddInParameter(cmd, "@LackGrabBars", DbType.Boolean, s.LackGrabBars);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            return !res.Equals(0); // to be qa'd
        }


        internal bool UpdateScreeningHrngLss( int patientId, bool? hearngDffclts = null, bool? strainHearng = null) {

            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[UpdateScreeningHrngLss]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            //_db.AddInParameter(cmd, "@Depressed", DbType.Boolean, depressed);
            //_db.AddInParameter(cmd, "@LittleInterest", DbType.Boolean, littleInterest);
            //_db.AddInParameter(cmd, "@Unsteady", DbType.Boolean, unsteady);
            //_db.AddInParameter(cmd, "@LivesAlone", DbType.Boolean, livesAlone);
            //_db.AddInParameter(cmd, "@NeedHelpWithMeals", DbType.Boolean, needHelpWithMeals);
            _db.AddInParameter(cmd, "@HearingDifficulties", DbType.Boolean, hearngDffclts);
            _db.AddInParameter(cmd, "@StrainedHearing", DbType.Boolean, strainHearng);
            //_db.AddInParameter(cmd, "@HallwayRugs", DbType.Boolean, s.HallwayRugs);
            //_db.AddInParameter(cmd, "@LackGrabBars", DbType.Boolean, s.LackGrabBars);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            return !res.Equals(0); // to be qa'd
        }

        internal bool UpdateScreeningHmSft( int patientId, bool? rugs = null, bool? lackGrabBars = null) {

            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[UpdateScreeningHmSft]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@HallwayRugs", DbType.Boolean, rugs);
            _db.AddInParameter(cmd, "@LackGrabBars", DbType.Boolean, lackGrabBars);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            return !res.Equals(0); // to be qa'd
        }
        internal bool UpdateScreening( int patientId, Screening s) {

            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[UpdateScreening]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@Depressed", DbType.Boolean, s.Depressed);
            _db.AddInParameter(cmd, "@LittleInterest", DbType.Boolean, s.LittleInterest);
            _db.AddInParameter(cmd, "@Unsteady", DbType.Boolean, s.Unsteady);
            _db.AddInParameter(cmd, "@LivesAlone", DbType.Boolean, s.LivesAlone);
            _db.AddInParameter(cmd, "@NeedHelpWithMeals", DbType.Boolean, s.NeedHelpWithMeals);
            _db.AddInParameter(cmd, "@HearingDifficulties", DbType.Boolean, s.HearingDifficulties);
            _db.AddInParameter(cmd, "@StrainedHearing", DbType.Boolean, s.StrainedHearing);
            _db.AddInParameter(cmd, "@HallwayRugs", DbType.Boolean, s.HallwayRugs);
            _db.AddInParameter(cmd, "@LackGrabBars", DbType.Boolean, s.LackGrabBars);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            return !res.Equals(0); // to be qa'd
        }

        private int GetOptionLookupId( PrvntvBase p) {
            int ret = -1;
            var optionsIds = new Lookup("Preventive").Listing;
            if ( p.Need != false || p.DateOfLastService != null || p.DueDate != null) {
                var qn = p.GetType().FullName.Replace("awv.", "");
                foreach ( var z in optionsIds) {
                    if ( z.Value.Equals( qn)) {
                        return z.Key;
                    }
                }
                //Console.WriteLine();
            }
            return ret;
        }

        private void AddDataTableRow( PrvntvBase p, ref DataTable dt) {
            var id = GetOptionLookupId( p);
            if (!id.Equals(-1)) {
                dt.Rows.Add( id,  p.Need, p.DateOfLastService, p.DueDate, DateTime.Now, DateTime.Now);
            }
        }
        internal bool UpdatePreventive( int patientId, Preventive p) {

            var dtXRefNumbers_TVP = new DataTable("XRef_TVP");
            dtXRefNumbers_TVP.Columns.Add("OptionsLookupId", typeof(int));
            dtXRefNumbers_TVP.Columns.Add("Need", typeof(bool));
            dtXRefNumbers_TVP.Columns.Add("DateOfLastService", typeof(DateTime));
            dtXRefNumbers_TVP.Columns.Add("DueDate", typeof(DateTime));
            dtXRefNumbers_TVP.Columns.Add("AddedOn", typeof(DateTime));
            dtXRefNumbers_TVP.Columns.Add("ModifiedOn", typeof(DateTime));

            AddDataTableRow(p.AbdmnlAortcAnursm, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.AlchlMisuseAndCnslng, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.BonDensitMeasrmnt, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.CardiovasclrScrenngs, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.ColorectalCancerFlxblSigmdscp, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.ColorectalCancerScrnngColonscp, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.ColorectalCancerStoolSampl, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.Depression, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.DiabetisScrenng, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.Glaucoma, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.HIV, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.Mammogrm, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.MedNutrcnThrpy, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.NextAWV, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.ObestyAndCounslg, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.PapSmr, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.ProsttCncr, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.TobaccUseCounslg, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.Vaccine_Flu, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.Vaccine_HepB, ref dtXRefNumbers_TVP);
            AddDataTableRow(p.Vaccine_Pneumo, ref dtXRefNumbers_TVP);

            //dtXRefNumbers_TVP.WriteXml(@"C:\Users\Alexander\Desktop\t.xml");

            #region [dbo].[UpdatePreventive]
            //            proc[dbo].[UpdatePreventive]
            //              @PatientId      int,
            //              @PreventiveXRef dbo.preventive_tvp READONLY as
            //              begin
            //                  delete from dbo.PreventiveXRef where PatientId = @PatientId

            //                  insert into dbo.PreventiveXRef
            //                  select
            //                      @PatientId, x.OptionsLookupId, x.Need, x.DateOfLastService, x.DueDate, getdate(), getdate()
            //                  from @PreventiveXRef x
            //              end 
            #endregion

            var _db = (SqlDatabase) DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[UpdatePreventive]");

            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, patientId);
            _db.AddInParameter(cmd, "@PreventiveXRef", SqlDbType.Structured, dtXRefNumbers_TVP);

            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            return !res.Equals(0); // to be qa'd
            return true;
        }

        internal Patient GetPatient( int id) {

            var p = new Patient();
            p.PatientId = id;
            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("dbo.GetPatient");
            _db.AddInParameter(cmd, "@PatientId", DbType.Int32, id);
            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteDataSet(cmd);

            if ( res.Tables[0].Rows.Count.Equals(0)) {
                return null;
            }

            #region PATIENT BASE
            var dtPatient = res.Tables[0];
            var ptnt = dtPatient.Rows[0];
            p.FName = ptnt["FirstName"].ToString();
            p.LName = ptnt["LastName"].ToString();
            p.MName = ptnt["MiddleInit"].ToString();
            p.DOB = Common.GetNullableDateTimeValue( ptnt["DOB"].ToString());
            p.Gender = GetGenderValue( ptnt["Gender"].ToString());  
            p.HeightInCM = Common.GetNullableDouble( ptnt["Height"].ToString());
            p.Weight = Common.GetNullableDouble( ptnt["Weight"].ToString());
            p.BMI = Common.GetNullableDouble( ptnt["BMI"].ToString());
            p.Waist = Common.GetNullableDouble( ptnt["Waist"].ToString());
            p.BloodPressure = new BloodPressure( Common.GetNullableInt( ptnt["BpS"].ToString()), Common.GetNullableInt( ptnt["BpD"].ToString()));
            p.Temp = Common.GetNullableDouble( ptnt["Temp"].ToString());
            #endregion


            #region TOBACCO XREF
            var lstTbccKind = new List<HistorySocial._tobaccoKind>();
            var dtTobacco = res.Tables[1];
            if (dtTobacco.Rows.Count > 0) {
                foreach (DataRow drTbc in dtTobacco.Rows) {
                    switch (drTbc["Descr"].ToString().ToUpper()) {
                        case "PIPE": lstTbccKind.Add(HistorySocial._tobaccoKind.Pipe); break;
                        case "CIGAR": lstTbccKind.Add(HistorySocial._tobaccoKind.Cigar); break;
                        case "CHEW": lstTbccKind.Add(HistorySocial._tobaccoKind.Chew); break;
                        case "CIGARETTES": lstTbccKind.Add(HistorySocial._tobaccoKind.Cigarettes); break;
                    }
                }
            } 
            #endregion


            #region HISTORY SOCIAL
            var dtHistorySocial = res.Tables[2];
            if (dtHistorySocial.Rows.Count > 0) {
                var hs = dtHistorySocial.Rows[0];
                var phs = new HistorySocial();

                phs.TobaccoEverUsed = Common.GetNullableBool(hs["TobaccoEverUsed"].ToString());
                phs.TobaccoKind = lstTbccKind; 
                phs.TobaccoTimesPerWeek = Common.GetNullableInt(hs["TobaccoTimesPerWeek"].ToString());
                phs.AlcoholUse = Common.GetNullableBool(hs["Alcohol"].ToString());
                phs.AlcoholTimesPerWeek = Common.GetNullableInt(hs["AlcoholPerWeek"].ToString());
                phs.RecDrugsUse = Common.GetNullableBool(hs["DrugsUse"].ToString());
                phs.RecDrugsTypes = hs["DrugTypes"].ToString();
                phs.Exercise = Common.GetNullableBool(hs["Exercise"].ToString());
                phs.ExerciseTimesPerWeek = Common.GetNullableInt(hs["ExerciseTimesPerWeek"].ToString());
                phs.ExerciseTypes = hs["ExerciseTypes"].ToString();
                phs.SpecialDiet = Common.GetNullableBool(hs["SpecialDiet"].ToString());
                phs.SpecialDietReason = hs["SpecialDietReason"].ToString();
                phs.AlwaysBuckledUp = Common.GetNullableBool(hs["UseSeatBelt"].ToString());
                phs.SunscreenWorn = Common.GetNullableBool(hs["UseSunscreen"].ToString());
                phs.ProblemsDressFeed = Common.GetNullableBool(hs["IssuesDressingFeeding"].ToString());
                phs.NeedHelpShopping = Common.GetNullableBool(hs["IssuesShoppingHousekeeping"].ToString());
                phs.Occupation = hs["Occupation"].ToString();
                phs.HomeEnvironment = GetHomeEnvir(hs["HomeEnvir"].ToString());
                phs.HomeEnvironmentOther = hs["HomeEnvirOther"].ToString();

                p.HistorySocial = phs; 
            }


            #endregion


            #region HISTORY FAMILY

            var familyMemberIndexes = new Lookup("FamilyMembers").Listing;
            var diseaseIndexes = new Lookup("Disease").Listing;

            var dtHistoryFamily = res.Tables[3];
            var phf = new List<HistoryFamily>();
            foreach ( DataRow drHF in dtHistoryFamily.Rows) {
                var member = Convert.ToInt16( drHF["FamilyMemberId"].ToString());
                var disease = Convert.ToInt16( drHF["DisorderDescrId"].ToString());
                phf.Add( new HistoryFamily( member, disease));
            }
            p.HistoryFamily = phf;
            #endregion


            #region MEDICAL.HOSPITAL VISITS
            var dtMedHospVisit = res.Tables[4];
            var lpMH = new List<HospitalVisit>();
            foreach ( DataRow dr in dtMedHospVisit.Rows) {
                var pMH = new HospitalVisit();
                pMH.Reason = dr["Reason"].ToString();
                pMH.Facility = dr["Facility"].ToString();
                pMH.Physician = dr["Physician"].ToString();

                DateTime visitDate;
                if (DateTime.TryParse(dr["VisitDate"].ToString(), out visitDate)) {
                    pMH.VisitDate = visitDate;
                } else {
                    pMH.VisitDate = null;
                }
                lpMH.Add( pMH);
            }

            var medical = new Medical();
            medical.HospitalVisits = lpMH;
            #endregion


            #region MEDICAL.ALLERGIES
            var dtMedAllergy = res.Tables[5];
            var lpAllrg = new List<Allergy>();
            foreach (DataRow dr in dtMedAllergy.Rows) {
                lpAllrg.Add( new Allergy(dr["Allergy"].ToString(), dr["TypeOfReaction"].ToString()));
            }
            medical.AllergyList = lpAllrg;
            #endregion


            #region MEDICAL.MEDICATIONS
            var dtMed_Mdctns = res.Tables[6];
            var lpMdctns = new List<Medication>();
            foreach (DataRow dr in dtMed_Mdctns.Rows)  {
                var pMH = new Medication();
                pMH.Name = dr["MedName"].ToString();
                pMH.Frequency = dr["Frequency"].ToString();
                pMH.DateStarted = Common.GetNullableDateTimeValue(dr["DateStarted"].ToString());
                pMH.DateEnded = Common.GetNullableDateTimeValue(dr["DateEnded"].ToString());
                lpMdctns.Add(pMH);
            }
            medical.Medications = lpMdctns;
            #endregion


            #region MEDICAL.PROVIDERS
            var dtMed_Provider = res.Tables[7];
            var lpPrvdrs = new List<Provider>();
            foreach ( DataRow dr in dtMed_Provider.Rows) {
                var pp = new Provider();
                pp.NameAndSpecialty = dr["PrvdrNmAndSpclty"].ToString();
                pp.TypeOfCare = dr["TypeOfCare"].ToString();
                pp.DateEnded = Common.GetNullableDateTimeValue( dr["DateEnded"].ToString());
                lpPrvdrs.Add(pp);
            }
            medical.OtherProviders = lpPrvdrs;
            #endregion


            p.Medical = medical;



            #region SCREENING

            var screening = new Screening();
            var dtScreening = res.Tables[8];
            if (dtScreening.Rows.Count > 0){
                var scr = dtScreening.Rows[0];

                screening.Depressed = Common.GetNullableBool(scr["Depressed"].ToString());
                screening.LittleInterest = Common.GetNullableBool(scr["LittleInterest"].ToString());
                screening.Unsteady = Common.GetNullableBool(scr["Unsteady"].ToString());
                screening.LivesAlone = Common.GetNullableBool(scr["LivesAlone"].ToString());
                screening.NeedHelpWithMeals = Common.GetNullableBool(scr["NeedHelpWithMeals"].ToString());
                screening.HearingDifficulties = Common.GetNullableBool(scr["HearingDifficulties"].ToString());
                screening.StrainedHearing = Common.GetNullableBool(scr["StrainedHearing"].ToString());
                screening.HallwayRugs = Common.GetNullableBool(scr["HallwayRugs"].ToString());
                screening.LackGrabBars = Common.GetNullableBool(scr["LackGrabBars"].ToString());

            }

            var dtScreeningMiniCog = res.Tables[9];
            if ( dtScreeningMiniCog.Rows.Count > 0) {
                var scrMC = dtScreeningMiniCog.Rows[0];

                screening.WordListVersion = Common.GetNullableInt( scrMC["WordListVersion"].ToString());
                screening.PersonAnswerA = Common.GetNullableInt( scrMC["PersonAnswerA"].ToString());
                screening.PersonAnswerB = Common.GetNullableInt( scrMC["PersonAnswerB"].ToString());
                screening.PersonAnswerC = Common.GetNullableInt( scrMC["PersonAnswerC"].ToString());
                screening.ScoringWordRecall = Common.GetNullableInt( scrMC["ScoringWordRecall"].ToString());
                screening.ScoringClockDraw = Common.GetNullableInt( scrMC["ScoringClockDraw"].ToString());
            }
            p.Screening = screening; 


            #region PREVENTIVE

            var dtPreventive  = res.Tables[10];
            if (dtPreventive.Rows.Count > 0) {
                var prvntv = new Preventive();
                foreach (DataRow drPrvnt in dtPreventive.Rows) {

                    //26  AbdmnlAortcAnursm
                    if ( drPrvnt["Descr"].ToString().ToUpper().Equals( "AbdmnlAortcAnursm".ToUpper() )) {
                        //object instnc = Activator.CreateInstanceFrom("");
                        var _AbdmnlAortcAnursm = new AbdmnlAortcAnursm();
                        _AbdmnlAortcAnursm.Need = Common.GetNullableBool( drPrvnt["Need"].ToString());
                        _AbdmnlAortcAnursm.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _AbdmnlAortcAnursm.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.AbdmnlAortcAnursm = _AbdmnlAortcAnursm;  
                    }

                    //27  AlchlMisuseAndCnslng
                    if ( drPrvnt["Descr"].ToString().ToUpper().Equals("AlchlMisuseAndCnslng".ToUpper() )) {
                        var _AlchlMisuseAndCnslng = new AlchlMisuseAndCnslng();
                        _AlchlMisuseAndCnslng.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _AlchlMisuseAndCnslng.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _AlchlMisuseAndCnslng.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.AlchlMisuseAndCnslng = _AlchlMisuseAndCnslng;  
                    }

                    //28  BonDensitMeasrmnt
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("BonDensitMeasrmnt".ToUpper())) {
                        var _BonDensitMeasrmnt = new BonDensitMeasrmnt();
                        _BonDensitMeasrmnt.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _BonDensitMeasrmnt.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _BonDensitMeasrmnt.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.BonDensitMeasrmnt = _BonDensitMeasrmnt;  
                    }

                    //29  CardiovasclrScrenngs
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("CardiovasclrScrenngs".ToUpper())) {
                        var _CardiovasclrScrenngs = new CardiovasclrScrenngs();
                        _CardiovasclrScrenngs.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _CardiovasclrScrenngs.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _CardiovasclrScrenngs.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.CardiovasclrScrenngs = _CardiovasclrScrenngs;  
                    }

                    //31  ColorectalCancerFlxblSigmdscp
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("ColorectalCancerFlxblSigmdscp".ToUpper())) {
                        var _ColorectalCancerFlxblSigmdscp = new ColorectalCancerFlxblSigmdscp();
                        _ColorectalCancerFlxblSigmdscp.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _ColorectalCancerFlxblSigmdscp.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _ColorectalCancerFlxblSigmdscp.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.ColorectalCancerFlxblSigmdscp = _ColorectalCancerFlxblSigmdscp;
                    }

                    //32  ColorectalCancerScrnngColonscp
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("ColorectalCancerScrnngColonscp".ToUpper())) {
                        var _ColorectalCancerScrnngColonscp = new ColorectalCancerScrnngColonscp();
                        _ColorectalCancerScrnngColonscp.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _ColorectalCancerScrnngColonscp.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _ColorectalCancerScrnngColonscp.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.ColorectalCancerScrnngColonscp = _ColorectalCancerScrnngColonscp;
                    }

                    //30  ColorectalCancerStoolSampl
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("ColorectalCancerStoolSampl".ToUpper())) {
                        var _ColorectalCancerStoolSampl = new ColorectalCancerStoolSampl();
                        _ColorectalCancerStoolSampl.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _ColorectalCancerStoolSampl.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _ColorectalCancerStoolSampl.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.ColorectalCancerStoolSampl = _ColorectalCancerStoolSampl;
                    }

                    //33  Depression
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("Depression".ToUpper())) {
                        var _Depression = new Depression();
                        _Depression.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _Depression.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _Depression.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.Depression = _Depression;
                    }

                    //34  DiabetisScrenng
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("DiabetisScrenng".ToUpper())) {
                        var _DiabetisScrenng = new DiabetisScrenng();
                        _DiabetisScrenng.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _DiabetisScrenng.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _DiabetisScrenng.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.DiabetisScrenng = _DiabetisScrenng;
                    }


                    //35  Glaucoma
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("Glaucoma".ToUpper())) {
                        var _Glaucoma = new Glaucoma();
                        _Glaucoma.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _Glaucoma.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _Glaucoma.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.Glaucoma = _Glaucoma;  
                    }

                    //36  HIV
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("HIV".ToUpper())) {
                        var _HIV = new HIV();
                        _HIV.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _HIV.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _HIV.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.HIV = _HIV;  
                    }



                    //37  Mammogrm
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("Mammogrm".ToUpper())) {
                        var _Mammogrm = new Mammogrm();
                        _Mammogrm.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _Mammogrm.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _Mammogrm.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.Mammogrm = _Mammogrm;
                    }


                    //38  MedNutrcnThrpy
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("MedNutrcnThrpy".ToUpper())) {
                        var _MedNutrcnThrpy = new MedNutrcnThrpy();
                        _MedNutrcnThrpy.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _MedNutrcnThrpy.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _MedNutrcnThrpy.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.MedNutrcnThrpy = _MedNutrcnThrpy;
                    }


                    //46  NextAWV
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("NextAWV".ToUpper())) {
                        var _NextAWV = new NextAWV();
                        _NextAWV.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _NextAWV.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _NextAWV.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.NextAWV = _NextAWV;
                    }


                    //39  ObestyAndCounslg
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("ObestyAndCounslg".ToUpper())) {
                        var _ObestyAndCounslg = new ObestyAndCounslg();
                        _ObestyAndCounslg.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _ObestyAndCounslg.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _ObestyAndCounslg.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.ObestyAndCounslg = _ObestyAndCounslg;
                    }


                    //40  PapSmr
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("PapSmr".ToUpper())) {
                        var _PapSmr = new PapSmr();
                        _PapSmr.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _PapSmr.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _PapSmr.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.PapSmr = _PapSmr;
                    }


                    //41  ProsttCncr
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("ProsttCncr".ToUpper())) {
                        var _ProsttCncr = new ProsttCncr();
                        _ProsttCncr.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _ProsttCncr.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _ProsttCncr.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.ProsttCncr = _ProsttCncr;
                    }


                    //42  TobaccUseCounslg
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("TobaccUseCounslg".ToUpper())) {
                        var _TobaccUseCounslg = new TobaccUseCounslg();
                        _TobaccUseCounslg.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _TobaccUseCounslg.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _TobaccUseCounslg.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.TobaccUseCounslg = _TobaccUseCounslg;
                    }


                    //44  Vaccine_Flu
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("Vaccine_Flu".ToUpper()))  {
                        var _Vaccine_Flu = new Vaccine_Flu();
                        _Vaccine_Flu.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _Vaccine_Flu.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _Vaccine_Flu.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.Vaccine_Flu = _Vaccine_Flu;
                    }


                    //43  Vaccine_HepB
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("Vaccine_HepB".ToUpper())) {
                        var _Vaccine_HepB = new Vaccine_HepB();
                        _Vaccine_HepB.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _Vaccine_HepB.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _Vaccine_HepB.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.Vaccine_HepB = _Vaccine_HepB;
                    }


                    //45  Vaccine_Pneumo
                    if (drPrvnt["Descr"].ToString().ToUpper().Equals("Vaccine_Pneumo".ToUpper())) {
                        var _Vaccine_Pneumo = new Vaccine_Pneumo();
                        _Vaccine_Pneumo.Need = Common.GetNullableBool(drPrvnt["Need"].ToString());
                        _Vaccine_Pneumo.DateOfLastService = Common.GetNullableDateTimeValue(drPrvnt["DateOfLastService"].ToString());
                        _Vaccine_Pneumo.DueDate = Common.GetNullableDateTimeValue(drPrvnt["DueDate"].ToString());
                        prvntv.Vaccine_Pneumo = _Vaccine_Pneumo;
                    }



                }



                p.Screening.Preventive = prvntv; 
            }

            #endregion



            #endregion


            Console.WriteLine();

            return p;
        }


        internal List<PatientBase> GetAllPatients() {
            var lPB = new List<PatientBase>();
            var _db = DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand( "dbo.GetPatientsBasic");
            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteDataSet(cmd);
            var rws = res.Tables[0].Rows;
            foreach ( DataRow dr in rws) {
                var p = new PatientBase();
                p.DOB = Common.GetNullableDateTimeValue( dr["DOB"].ToString());
                p.FName = dr["FirstName"].ToString();
                p.LName = dr["LastName"].ToString();
                p.MName = dr["MiddleInit"].ToString();
                p.PatientId = Convert.ToInt32( dr["PatientId"].ToString());
                if ( !string.IsNullOrEmpty( dr["Gender"].ToString())) {
                    p.Gender = dr["Gender"].ToString().Equals("False") ? PatientBase._Gender.Male : PatientBase._Gender.Female;
                }
                lPB.Add(p);
            }
            return lPB;
        }

        private HistorySocial._homeEnvir GetHomeEnvir(string homeEnvirIndex) {
            int i;
            if (int.TryParse( homeEnvirIndex, out i)) {
                switch (i) {
                    case -1: return HistorySocial._homeEnvir.na;
                    case 0: return HistorySocial._homeEnvir.PrivateHome;
                    case 1: return HistorySocial._homeEnvir.AssistedLiving;
                    case 2: return HistorySocial._homeEnvir.Other;
                }
            }
            return HistorySocial._homeEnvir.na;
        }

        //private List<HistorySocial._tobaccoKind> GetTobacco( string tobaccoIndex) {
        //    var ret = new List<HistorySocial._tobaccoKind>();
        //    //  na, Pipe, Cigar, Chew, Cigarettes
        //    int i;
        //    if ( int.TryParse( tobaccoIndex, out i)) {
        //        switch (i) {
        //            case 0: ret.Add( HistorySocial._tobaccoKind.na); break;
        //            //case 1: return HistorySocial._tobaccoKind.Pipe; 
        //            //case 2: return HistorySocial._tobaccoKind.Cigar; 
        //            //case 3: return HistorySocial._tobaccoKind.Chew;
        //            //case 4: return HistorySocial._tobaccoKind.Cigarettes; 
        //        }
        //    }
        //    return ret;
        //}

        //private int? GetNullableInt(string d)  {
        //    if (!string.IsNullOrEmpty(d)) {
        //        int res;
        //        if (int.TryParse(d, out res)) {
        //            return res;
        //        }
        //    }
        //    return null;
        //}

        //private double? GetNullableDouble( string d) {
        //    if ( !string.IsNullOrEmpty(d)){
        //        double res;
        //        if ( double.TryParse(d, out res)) {
        //            return res;
        //        }
        //    }
        //    return null;
        //}
        //private bool? GetNullableBool(string v) {
        //    if ( !string.IsNullOrEmpty(v)) {
        //        if (v.ToUpper().Equals("TRUE")) {
        //            return true;
        //        }
        //        if (v.ToUpper().Equals("FALSE")) {
        //            return false;
        //        }
        //    }
        //    return null;
        //}

        //private DateTime? GetNullableDateTimeValue(string d) {
        //    if (!string.IsNullOrEmpty( d)) {
        //        DateTime res;
        //        if ( DateTime.TryParse( d, out res)) {
        //            return res;
        //        }
        //    }
        //    return null;
        //}

        private PatientBase._Gender? GetGenderValue( string v) {
            if (v != null) {
                if ( v.ToUpper().Equals("TRUE")) { return Patient._Gender.Female; }
                if ( v.ToUpper().Equals("FALSE")) { return Patient._Gender.Male;}
            }
            return null;
        } 

        internal int AddPatient( Patient p) {

            var _db = (SqlDatabase) DatabaseFactory.CreateDatabase(cnn);
            var cmd = _db.GetStoredProcCommand("[dbo].[CreatePatient]");


            _db.AddInParameter(cmd, "@FirstName", DbType.String, p.FName);
            _db.AddInParameter(cmd, "@LastName", DbType.String, p.LName);
            _db.AddInParameter(cmd, "@MiddleInit", DbType.String, p.MName);
            _db.AddInParameter(cmd, "@DOB", DbType.Date, p.DOB );
            _db.AddInParameter(cmd, "@Gender", DbType.Int16, p.Gender);
            _db.AddInParameter(cmd, "@Height", DbType.Double, p.HeightInCM);
            _db.AddInParameter(cmd, "@Weight", DbType.Double, p.Weight);
            _db.AddInParameter(cmd, "@BMI", DbType.Double, p.BMI);
            _db.AddInParameter(cmd, "@Waist", DbType.Double, p.Waist);

            int? dia = null; int? sys = null;
            if ( p.BloodPressure != null) {
                dia = p.BloodPressure.Diastolic;
                sys = p.BloodPressure.Systolic;
            }
            _db.AddInParameter(cmd, "@BpD", DbType.Int16, dia);
            _db.AddInParameter(cmd, "@BpS", DbType.Int16, sys);
            _db.AddInParameter(cmd, "@Temp", DbType.Double, p.Temp);




            _db.AddInParameter(cmd, "@TobaccoEverUsed", DbType.Boolean, p.HistorySocial.TobaccoEverUsed);
            _db.AddInParameter(cmd, "@TobaccoKind", DbType.Int16, p.HistorySocial.TobaccoKind);
            _db.AddInParameter(cmd, "@TobaccoTimesPerWeek", DbType.Int16, p.HistorySocial.TobaccoTimesPerWeek);

            _db.AddInParameter(cmd, "@Alcohol", DbType.Boolean, p.HistorySocial.AlcoholUse);  //bit = null,
            _db.AddInParameter(cmd, "@AlcoholPerWeek", DbType.Int16, p.HistorySocial.AlcoholTimesPerWeek); //int = null,
            _db.AddInParameter(cmd, "@DrugsUse", DbType.Boolean, p.HistorySocial.RecDrugsUse); //bit = null,
            _db.AddInParameter(cmd, "@DrugTypes", DbType.String, p.HistorySocial.RecDrugsTypes); //numeric = null,
            _db.AddInParameter(cmd, "@Exercise", DbType.Boolean, p.HistorySocial.Exercise); //bit = null,
            _db.AddInParameter(cmd, "@ExerciseTimesPerWeek", DbType.Int16, p.HistorySocial.ExerciseTimesPerWeek); //numeric = null,
            _db.AddInParameter(cmd, "@ExerciseTypes", DbType.String, p.HistorySocial.ExerciseTypes);// nvarchar(250) = null,
            _db.AddInParameter(cmd, "@SpecialDiet", DbType.Boolean, p.HistorySocial.SpecialDiet);// bit = null,
            _db.AddInParameter(cmd, "@SpecialDietReason", DbType.String, p.HistorySocial.SpecialDietReason);//      nvarchar(250) = null,
            _db.AddInParameter(cmd, "@UseSeatBelt", DbType.Boolean, p.HistorySocial.AlwaysBuckledUp);// bit = null,
            _db.AddInParameter(cmd, "@UseSunscreen", DbType.Boolean, p.HistorySocial.SunscreenWorn);//           bit = null,
            _db.AddInParameter(cmd, "@IssuesDressingFeeding", DbType.Boolean, p.HistorySocial.ProblemsDressFeed);// bit = null,
            _db.AddInParameter(cmd, "@IssuesShoppingHousekeeping", DbType.Boolean, p.HistorySocial.NeedHelpShopping);// bit = null,
            _db.AddInParameter(cmd, "@Occupation", DbType.String, p.HistorySocial.Occupation);// nvarchar(250) = null,
            _db.AddInParameter(cmd, "@HomeEnvir", DbType.Int16, p.HistorySocial.HomeEnvironment);// numeric = null,
            _db.AddInParameter(cmd, "@HomeEnvirOther", DbType.String, p.HistorySocial.HomeEnvironmentOther);

            // add table variable parameter here
            #region HISTORY FAMILY
            var dtHistoryFamily = new DataTable("dtHistoryFamily");
            dtHistoryFamily.Columns.Add("FamilyMember", typeof(int));
            dtHistoryFamily.Columns.Add("Disease", typeof(int));


            #region TEMPORARY CONSTANTS - TO BE CHANGED TO LOOKUP VALUES
            //6   Aunts
            //5   Brothers
            //9   Daughters
            //2   Father
            //3   Mother
            //0   na
            //1   Self
            //4   Sisters
            //8   Sons
            //7   Uncles

            //16  Alcoholism
            //20  BreastCancer
            //19  ColonOrRectalCancer
            //10  Deceased
            //18  Depression
            //15  GeneticDisorder
            //12  HeartDisease
            //11  Hypertension
            //14  KideneyDisease
            //17  LiverDisease
            //21  OtherCancer
            //13  Stroke 
            #endregion

            //var enumValues = Enum.GetValues( typeof( HistoryFamily.FamilyMembers));
            //foreach (var s in enumValues) {
            //    Console.WriteLine( s.ToString());
            //}
            //if (p.HistoryFamily.Alcoholism.Equals( HistoryFamily.FamilyMembers.Aunts)) {
            //    dtHistoryFamily.Rows.Add( HistoryFamily.FamilyMembers.Aunts, 16);
            //}
            dtHistoryFamily.Rows.Add(6, 16);
            dtHistoryFamily.Rows.Add(2, 10);
            dtHistoryFamily.Rows.Add(3, 10);
            dtHistoryFamily.Rows.Add(1, 21);
            dtHistoryFamily.Rows.Add(8, 11);
            _db.AddInParameter(cmd, "@XRef", SqlDbType.Structured, dtHistoryFamily); 
            #endregion


            #region HOSPVISITS               DBO.HOSPVISIT_TVP       READONLY
            var dtHV = new DataTable("dtHospitalVisits");
            dtHV.Columns.Add("Reason", typeof(string));
            dtHV.Columns.Add("Facility", typeof(string));
            dtHV.Columns.Add("Physician", typeof(string));
            dtHV.Columns.Add("VisitDate", typeof(DateTime));

            dtHV.Rows.Add("Nasmork", "UPenn", "Dr. Joe Schmoe", new DateTime(2017, 1, 1));
            dtHV.Rows.Add("Srachka", "Hahnemann", "Dr. Lee Hyi", new DateTime(2016, 12, 31));
            _db.AddInParameter(cmd, "@HospVisits", SqlDbType.Structured, dtHV);
            #endregion


            #region ALLERGIES                DBO.ALLERGY_TVP         READONLY
            var dtAllrgs = new DataTable("dtAllrgs");
            dtAllrgs.Columns.Add("Allergy", typeof(string));
            dtAllrgs.Columns.Add("TypeOfReaction", typeof(string));

            dtAllrgs.Rows.Add("some allergy", "Itchy I");
            dtAllrgs.Rows.Add("some more allergy", "Throat issues");
            _db.AddInParameter(cmd, "@Allergies", SqlDbType.Structured, dtAllrgs);
            #endregion


            #region MEDICATIONS              DBO.MEDICATION_TVP      READONLY
            var dtMedications = new DataTable("dtMedications");
            dtMedications.Columns.Add("MedName", typeof(string));
            dtMedications.Columns.Add("Frequency", typeof(string));
            dtMedications.Columns.Add("DateStarted", typeof(DateTime));
            dtMedications.Columns.Add("DateEnded", typeof(DateTime));

            dtMedications.Rows.Add("aspirin", "daily", new DateTime(1989, 5, 13), null);
            dtMedications.Rows.Add("motriny", "anually", new DateTime(1990, 6, 29), null);
            dtMedications.Rows.Add("valirianka", "ni-weekly", new DateTime(2000, 5, 1), null);
            dtMedications.Rows.Add("p00rgen", "every hour", new DateTime(2017, 1, 8), null);
            _db.AddInParameter(cmd, "@Medications", SqlDbType.Structured, dtMedications);
            #endregion


            #region PROVIDERS                DBO.PROVIDER_TVP        READONLY
            //var dtProviders = new DataTable("dtProviders");
            //dtProviders.Columns.Add("PrvdrNmAndSpclty", typeof(string));
            //dtProviders.Columns.Add("TypeOfCare", typeof(string));
            //dtProviders.Columns.Add("DateEnded", typeof(DateTime));

            //dtProviders.Rows.Add("ArtiaHealth", "family dok", null);
            //dtProviders.Rows.Add("Doylestown Medical Associates", "men's health", null);
            //dtProviders.Rows.Add("University Of Penn", "ne znaiy", null);
            //_db.AddInParameter(cmd, "@Providers", SqlDbType.Structured, dtProviders);
            #endregion


            #region PREVENTIVE       DBO.PREVENTIVE_TVP	READONLY

            //[OptionsLookupId]     [int] NOT NULL,
            //[Need]                [bit] NULL,
            //[DateOfLastService]   [date] NULL,
            //[DueDate]             [date] NULL,
            //[AddedOn]             [datetime] NOT NULL,
            //[ModifiedOn]          [datetime] NULL

            var dtPreventive = new DataTable("dtPreventives");
            dtPreventive.Columns.Add("OptionsLookupId", typeof(int));
            dtPreventive.Columns.Add("Need", typeof(int));
            dtPreventive.Columns.Add("DateOfLastService", typeof(DateTime));
            dtPreventive.Columns.Add("DueDate", typeof(DateTime));
            dtPreventive.Columns.Add("AddedOn", typeof(DateTime));
            dtPreventive.Columns.Add("ModifiedOn", typeof(DateTime));

            dtPreventive.Rows.Add( 42, 1, DateTime.Now.AddMonths(-6), DateTime.Now.AddDays(-15), DateTime.Now, null);
            dtPreventive.Rows.Add( 43, 1, null, null, DateTime.Now, null);
            dtPreventive.Rows.Add( 44, 1, null, null, DateTime.Now, null);
            _db.AddInParameter(cmd, "@Preventive", SqlDbType.Structured, dtPreventive); 
            #endregion




            _db.AddInParameter(cmd, "@Depressed", DbType.Boolean, p.Screening.Depressed);
            _db.AddInParameter(cmd, "@LittleInterest", DbType.Boolean, p.Screening.LittleInterest);
            _db.AddInParameter(cmd, "@Unsteady", DbType.Boolean, p.Screening.Unsteady);
            _db.AddInParameter(cmd, "@LivesAlone", DbType.Boolean, p.Screening.LivesAlone);
            _db.AddInParameter(cmd, "@NeedHelpWithMeals", DbType.Boolean, p.Screening.NeedHelpWithMeals);
            _db.AddInParameter(cmd, "@HearingDifficulties", DbType.Boolean, p.Screening.HearingDifficulties);
            _db.AddInParameter(cmd, "@StrainedHearing", DbType.Boolean, p.Screening.StrainedHearing);
            _db.AddInParameter(cmd, "@HallwayRugs", DbType.Boolean, p.Screening.HallwayRugs);
            _db.AddInParameter(cmd, "@LackGrabBars", DbType.Boolean, p.Screening.LackGrabBars);



            _db.AddOutParameter(cmd, "@PatientId", DbType.Int32, int.MaxValue);


            cmd.CommandType = CommandType.StoredProcedure;
            var res = _db.ExecuteNonQuery(cmd);
            return Convert.ToInt32(_db.GetParameterValue(cmd, "@PatientId"));
        }
    }
}