﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Web.UI;
using System.Web.UI.WebControls;
using Aspose.Html.Rendering;
using Aspose.Html.Rendering.Pdf;
using Aspose.Html;

namespace awv {

    public partial class Wiz : Page {



        protected void grd_RowDeleted(object sender, GridViewDeletedEventArgs e) {
            //Toast("Deleted!");

            var gv = (GridView)sender;
            rblHsptlVst.Enabled = !(gv.Rows.Count > 1);
        }

        protected void grdAllrgs_RowDeleted(object sender, GridViewDeletedEventArgs e) {
            //Toast("Deleted!");

            var gv = (GridView)sender;
            rblAllrgs.Enabled = !(gv.Rows.Count > 1);
        }


        protected void grdPrvdrs_RowDeleted(object sender, GridViewDeletedEventArgs e) {
            //Toast("Deleted!");

            var gv = (GridView)sender;
            rblSeengOthrPrvdrs.Enabled = !(gv.Rows.Count > 1);
        }

        protected void Page_Load(object sender, EventArgs e) {


            //updtPnlMaster.Controls.Remove( btnPDF);
            

            if (!IsPostBack) {
                //LoadFrequencyOptionLists();
                wzrdPatient.ActiveStepIndex = 0;
                if (Request.QueryString["patientId"] != null) {
                    int patientId = -1;
                    if ( int.TryParse( Request.QueryString["patientId"], out patientId))
                    {
                        var p = new Patient().Get(patientId);

                        #region DEMOGRAPHIC INFO
                        txtLN.Text = p.LName;
                        txtFN.Text = p.FName;
                        txtMN.Text = p.MName;
                        txtDOB.Text = p.DOB?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        #endregion

                        #region VITALS
                        txtHeight.Text = p.HeightInCM.ToString();
                        txtWeight.Text = p.Weight.ToString();
                        txtBMI.Text = p.BMI.ToString();
                        txtWaist.Text = p.Waist.ToString();
                        txtBpS.Text = p.BloodPressure.Systolic.ToString();
                        txtBpD.Text = p.BloodPressure.Diastolic.ToString();
                        txtTemp.Text = p.Temp.ToString();
                        if (p.Gender != null)
                        {
                            rblGender.SelectedIndex = p.Gender.Value.Equals(Patient._Gender.Male) ? 0 : 1;
                        }
                        #endregion

                        #region HISTORY SOCIAL

                        #region TOBACCO
                        if (p.HistorySocial?.TobaccoEverUsed == null)
                        {
                            rblTbcc.SelectedIndex = -1;
                        }
                        else
                        {
                            rblTbcc.SelectedIndex = p.HistorySocial.TobaccoEverUsed == false ? 0 : 1;
                            pnlTbcc.Visible = (bool)p.HistorySocial.TobaccoEverUsed;
                            foreach (var i in p.HistorySocial.TobaccoKind)
                            {
                                chkTbccKind.Items.FindByText(i.ToString()).Selected = true;
                            }

                            if (p.HistorySocial.TobaccoTimesPerWeek == null)
                            {
                                ddlTbccFrqnc.SelectedIndex = -1;
                            }
                            else
                            {
                                var li = ddlTbccFrqnc.Items.FindByValue(p.HistorySocial.TobaccoTimesPerWeek.ToString());
                                if (li != null)
                                {
                                    li.Selected = true;
                                }
                            }

                        }
                        #endregion


                        #region ALCOHOL
                        if (p.HistorySocial?.AlcoholUse == null)
                        {
                            rblAlchl.SelectedIndex = -1;
                        }
                        else
                        {
                            rblAlchl.SelectedIndex = p.HistorySocial.AlcoholUse == false ? 0 : 1;
                            pnlAlchl.Visible = (bool)p.HistorySocial.AlcoholUse;

                            if (p.HistorySocial.AlcoholTimesPerWeek == null)
                            {
                                ddlAlchlDrnksPrWeek.SelectedIndex = -1;
                            }
                            else
                            {
                                var li = ddlAlchlDrnksPrWeek.Items.FindByValue(p.HistorySocial.AlcoholTimesPerWeek.ToString());
                                if (li != null)
                                {
                                    li.Selected = true;
                                }
                            }

                        }
                        #endregion


                        #region DRUGS
                        if (p.HistorySocial?.RecDrugsUse == null)
                        {
                            rblDrgs.SelectedIndex = -1;
                        }
                        else
                        {
                            rblDrgs.SelectedIndex = p.HistorySocial.RecDrugsUse == false ? 0 : 1;
                            pnlDrugs.Visible = (bool)p.HistorySocial.RecDrugsUse;
                            txtDrgTyps.Text = p.HistorySocial.RecDrugsTypes.ToString();
                        }
                        #endregion


                        #region EXERCISE
                        if (p.HistorySocial?.Exercise == null)
                        {
                            rblXcrcs.SelectedIndex = -1;
                        }
                        else
                        {
                            rblXcrcs.SelectedIndex = p.HistorySocial.Exercise == false ? 0 : 1;
                            pnlXcrcs.Visible = (bool)p.HistorySocial.Exercise;


                            if (p.HistorySocial.ExerciseTimesPerWeek == null)
                            {
                                ddlXcrcsTmsPrWeek.SelectedIndex = -1;
                            }
                            else
                            {
                                var li = ddlXcrcsTmsPrWeek.Items.FindByValue(p.HistorySocial.ExerciseTimesPerWeek.ToString());
                                if (li != null)
                                {
                                    li.Selected = true;
                                }
                            }



                            txtXcrcTypes.Text = p.HistorySocial.ExerciseTypes;
                        }
                        #endregion


                        #region SPECIAL DIET
                        if (p.HistorySocial?.SpecialDiet == null)
                        {
                            rblSpclDiet.SelectedIndex = -1;
                        }
                        else
                        {
                            rblSpclDiet.SelectedIndex = p.HistorySocial.SpecialDiet == false ? 0 : 1;
                            pnlSpclDiet.Visible = (bool)p.HistorySocial.SpecialDiet;
                            txtSpclDietReasn.Text = p.HistorySocial.SpecialDietReason;
                        }
                        #endregion


                        #region SEAT BELT
                        if (p.HistorySocial?.AlwaysBuckledUp == null)
                        {
                            rblBucklUp.SelectedIndex = -1;
                        }
                        else
                        {
                            rblBucklUp.SelectedIndex = p.HistorySocial.AlwaysBuckledUp == false ? 0 : 1;
                        }
                        #endregion


                        #region SUN SCREEN
                        if (p.HistorySocial?.SunscreenWorn == null)
                        {
                            rblWearSuncsren.SelectedIndex = -1;
                        }
                        else
                        {
                            rblWearSuncsren.SelectedIndex = p.HistorySocial.SunscreenWorn == false ? 0 : 1;
                        }
                        #endregion


                        #region DRESSING, FEEDING
                        if (p.HistorySocial?.ProblemsDressFeed == null)
                        {
                            rblPrblmsDrssng.SelectedIndex = -1;
                        }
                        else
                        {
                            rblPrblmsDrssng.SelectedIndex = p.HistorySocial.ProblemsDressFeed == false ? 0 : 1;
                        }
                        #endregion


                        #region SHOPPING, FOOD PREPARATION
                        if (p.HistorySocial?.NeedHelpShopping == null)
                        {
                            rblNeedHlpShppng.SelectedIndex = -1;
                        }
                        else
                        {
                            rblNeedHlpShppng.SelectedIndex = p.HistorySocial.NeedHelpShopping == false ? 0 : 1;
                        }
                        #endregion


                        #region OCCUPATION
                        txtOccptn.Text = p.HistorySocial?.Occupation;
                        #endregion


                        #region HOME ENVIRONMENT
                        if (p.HistorySocial != null) {
                            rblHomEnvir.SelectedIndex = (int)p.HistorySocial?.HomeEnvironment;
                            pnlHomEnvir.Visible = p.HistorySocial.HomeEnvironment.Equals(HistorySocial._homeEnvir.Other);
                            txtAsstdLivnOthr.Text = p.HistorySocial?.HomeEnvironmentOther;
                        }
                        #endregion


                        #endregion

                        #region HISTORY FAMILY

                        ucHistoryFamily.LoadControlOptions();
                        ucHistoryFamily.HistoryFamilyValues = p.HistoryFamily;

                        #endregion


                        #region MEDICAL

                        //medical - hospital visits
                        var hospVisits = p.Medical.HospitalVisits.Count;
                        rblHsptlVst.SelectedIndex = hospVisits.Equals(0) ? 0 : 1;
                        rblHsptlVst.Enabled = !(hospVisits > 0);
                        pnlHsptlvsts.Visible = !hospVisits.Equals(0);


                        //medical - allergies
                        var allergies = p.Medical.AllergyList.Count;
                        rblAllrgs.SelectedIndex = allergies.Equals(0) ? 0 : 1;
                        rblAllrgs.Enabled = !(allergies > 0);
                        pnlAllrgs.Visible = !allergies.Equals(0);


                        //medical - providers
                        var providers = p.Medical.OtherProviders.Count;
                        rblSeengOthrPrvdrs.SelectedIndex = providers.Equals(0) ? 0 : 1;
                        rblSeengOthrPrvdrs.Enabled = !(providers > 0);
                        pnlPrvdrs.Visible = !providers.Equals(0);
                        #endregion


                        #region SCREENING
                        //DEPRESSION
                        if (p.Screening.Depressed == null)
                        {
                            rblDprssd.SelectedIndex = -1;
                        }
                        else
                        {
                            rblDprssd.SelectedIndex = ((bool)p.Screening.Depressed) ? (1) : (0);
                        }

                        //LTTL INTRST
                        if (p.Screening.LittleInterest == null)
                        {
                            rblLttlIntrst.SelectedIndex = -1;
                        }
                        else
                        {
                            rblLttlIntrst.SelectedIndex = ((bool)p.Screening.LittleInterest) ? (1) : (0);
                        }


                        //UNSTEADY
                        if (p.Screening.Unsteady == null)
                        {
                            rblUnsteady.SelectedIndex = -1;
                        }
                        else
                        {
                            rblUnsteady.SelectedIndex = ((bool)p.Screening.Unsteady) ? (1) : (0);
                        }


                        //LIVES ALONE
                        if (p.Screening.LivesAlone == null)
                        {
                            rblLivesAlon.SelectedIndex = -1;
                        }
                        else
                        {
                            rblLivesAlon.SelectedIndex = ((bool)p.Screening.LivesAlone) ? (1) : (0);
                        }


                        //NEED HELP WITH MEALS
                        if (p.Screening.NeedHelpWithMeals == null)
                        {
                            rblNeedHelpWithMeals.SelectedIndex = -1;
                        }
                        else
                        {
                            rblNeedHelpWithMeals.SelectedIndex = ((bool)p.Screening.NeedHelpWithMeals) ? (1) : (0);
                        }


                        //rblHearngDffclts
                        if (p.Screening.HearingDifficulties == null)
                        {
                            rblHearngDffclts.SelectedIndex = -1;
                        }
                        else
                        {
                            rblHearngDffclts.SelectedIndex = ((bool)p.Screening.HearingDifficulties) ? (1) : (0);
                        }


                        //rblStrainHearng
                        if (p.Screening.StrainedHearing == null)
                        {
                            rblStrainHearng.SelectedIndex = -1;
                        }
                        else
                        {
                            rblStrainHearng.SelectedIndex = ((bool)p.Screening.StrainedHearing) ? (1) : (0);
                        }


                        //rblRugs
                        if (p.Screening.HallwayRugs == null)
                        {
                            rblRugs.SelectedIndex = -1;
                        }
                        else
                        {
                            rblRugs.SelectedIndex = ((bool)p.Screening.HallwayRugs) ? (1) : (0);
                        }


                        //rblLackGrabBars
                        if (p.Screening.LackGrabBars == null)
                        {
                            rblLackGrabBars.SelectedIndex = -1;
                        }
                        else
                        {
                            rblLackGrabBars.SelectedIndex = ((bool)p.Screening.LackGrabBars) ? (1) : (0);
                        }
                        #endregion


                        #region SCREENING.MINI-COG
                        ucMiniCog.WordListVersion = p.Screening.WordListVersion;
                        ucMiniCog.AnswerA = p.Screening.PersonAnswerA;
                        ucMiniCog.AnswerB = p.Screening.PersonAnswerB;
                        ucMiniCog.AnswerC = p.Screening.PersonAnswerC;
                        ucMiniCog.ScoringWordRecall = p.Screening.ScoringWordRecall;
                        ucMiniCog.ScoringClockDraw = p.Screening.ScoringClockDraw;
                        #endregion


                        #region SCREENING.PREVENTIVE
                        ucPreventive.Preventive = p.Screening.Preventive;
                        //if ( preventive != null) {
                        //    ucPreventive.Preventive = preventive;
                        //}
                        #endregion




                        //Console.WriteLine();

                        cntrlPtntDsplInf.DisplayInfo = p.FullName + " " + p.DOB?.ToString("MM/dd/yyyy") + " " + p.Gender;
                    }
                } else {
                    Console.WriteLine( wzrdPatient.ActiveStepIndex);
                    throw new Exception("error occured");
                }
                ScriptManager.RegisterStartupScript(updtPnlMaster, updtPnlMaster.GetType(), "scrptNoDups", "toastr.options.preventDuplicates = true;", true);
            } else {

            }

        }

        protected void btnSave_Click( object sender, EventArgs e) {
            Button o = (Button) sender;
            switch (o.CommandName) {
                case "Demographic": SaveDemographics(); break;
                case "Vitals": SaveVitals(); break;
                case "HstrScl":  SaveHstrScl(); break;
                case "ScrDprssn": SaveScreeningDprssn(); break;
                case "ScFnctn": SaveScreeningFnctn(); break;
                case "ScHrngLss": SaveScreeningHrngLss(); break;
                case "ScHmSft": SaveScreeningHmSft(); break;
                case "HstrFml": SaveHistoryFamily(); break;
                case "MinCog": SaveScreeningMinCog(); break;
                case "Prvntv": SavePrvntv(); break; 
            }
            ScriptManager.RegisterStartupScript( updtPnlMaster, updtPnlMaster.GetType(), "scrptSv", "toastr.success('Saved!', 'AWV')", true);
        }

        private void SaveScreeningDprssn()  {
            int dprssd = rblDprssd.SelectedIndex;
            int lttlIntrst = rblLttlIntrst.SelectedIndex;
            new Patient().SaveScreeningDprssn( 
                    Convert.ToInt32( Request.QueryString["patientId"].ToString()), 
                    dprssd, 
                    lttlIntrst);
        }

        private void SaveScreeningFnctn() {
            int unsteady = rblUnsteady.SelectedIndex;
            int livesAlon = rblLivesAlon.SelectedIndex;
            int needHlpWithMeals = rblNeedHelpWithMeals.SelectedIndex;
            new Patient().SaveScreeningFnctn( 
                    Convert.ToInt32( Request.QueryString["patientId"].ToString()), 
                    unsteady, 
                    livesAlon, 
                    needHlpWithMeals);
        }

        private void SaveScreeningHrngLss() {
            int HearngDffclts = rblHearngDffclts.SelectedIndex;
            int StrainHearng = rblStrainHearng.SelectedIndex;
            new Patient().SaveScreeningHrngLss( 
                    Convert.ToInt32( Request.QueryString["patientId"].ToString()),
                    HearngDffclts,
                    StrainHearng);
        }

        private void SaveScreeningHmSft() {
            int rugs = rblRugs.SelectedIndex;
            int lackGrabBars = rblLackGrabBars.SelectedIndex;
            new Patient().SaveScreeningHmSft( 
                    Convert.ToInt32( Request.QueryString["patientId"].ToString()),
                    rugs,
                    lackGrabBars);
        }

        private void SaveScreeningMinCog() {

            int patientId = Convert.ToInt32(Request.QueryString["patientId"].ToString());
            int? wordListVersion = ucMiniCog.WordListVersion;  
            int? a = ucMiniCog.AnswerA;  
            int? b = ucMiniCog.AnswerB;  
            int? c = ucMiniCog.AnswerC;  
            int? scoringWordRecall = ucMiniCog.ScoringWordRecall;
            int? scoringClockDraw = ucMiniCog.ScoringClockDraw;

            new Patient().SaveScreeningMiniCog( patientId, wordListVersion, a, b, c, scoringWordRecall, scoringClockDraw);
        }

        private bool SaveHistoryFamily() {
            var patientId = Convert.ToInt32( Request.QueryString["patientId"].ToString());
            return new Patient().SaveHistoryFamily( patientId, ucHistoryFamily.HistoryFamilyValues);
        }

        private bool SaveHstrScl() {
            var v = new HistorySocial();


            #region TOBACCO
            if (!rblTbcc.SelectedIndex.Equals(-1)) {
                v.TobaccoEverUsed = rblTbcc.SelectedValue.Equals("1");
                if (rblTbcc.SelectedValue.Equals("1"))  {
                    var tobaccoIndex = new Lookup("Tobacco").Listing;
                    var tobaccoKind = new List<HistorySocial._tobaccoKind>();
                    foreach (ListItem li in chkTbccKind.Items) {
                        if ( li.Selected) {
                            switch ( li.Text) {
                                case "Cigarettes": tobaccoKind.Add(HistorySocial._tobaccoKind.Cigarettes); break;
                                case "Chew": tobaccoKind.Add(HistorySocial._tobaccoKind.Chew); break;
                                case "Cigar": tobaccoKind.Add(HistorySocial._tobaccoKind.Cigar); break;
                                case "Pipe": tobaccoKind.Add(HistorySocial._tobaccoKind.Pipe); break;
                            }
                        }
                    }

                    //int ttpw;
                    //if ( int.TryParse( txtTbccTmsPrWeek.Text.Trim(), out ttpw)) {
                    //    Int16 _ttpw;
                    //    if (ttpw > Int16.MaxValue) {
                    //        _ttpw = Convert.ToInt16( ttpw.ToString().Substring(1, 4));
                    //    } else {
                    //        _ttpw = (Int16)ttpw;
                    //    }
                    //    v.TobaccoTimesPerWeek = _ttpw;
                    //}
                    v.TobaccoTimesPerWeek = Convert.ToInt16( ddlTbccFrqnc.SelectedItem.Value);


                    v.TobaccoKind = tobaccoKind;
                }
            }
            #endregion


            #region ALCOHOL
            if ( !rblAlchl.SelectedIndex.Equals(-1)) {
                v.AlcoholUse = rblAlchl.SelectedValue.Equals("1");
                if ( rblAlchl.SelectedValue.Equals("1")) {


                    //int drnkspw;
                    //if (int.TryParse( txtAlchlDrnksPrWeek.Text.Trim(), out drnkspw)) {
                    //    // check for Int16 overflow and trim if necessary
                    //    Int16 _drnkspw = (Int16)drnkspw;
                    //    v.AlcoholTimesPerWeek = _drnkspw;
                    //}
                    v.AlcoholTimesPerWeek = Convert.ToInt16( ddlAlchlDrnksPrWeek.SelectedItem.Value);

                }
            }
            #endregion


            #region DRUGS
            if ( !rblDrgs.SelectedIndex.Equals(-1)) {
                v.RecDrugsUse = rblDrgs.SelectedValue.Equals("1");
                if ( rblDrgs.SelectedValue.Equals("1")) {
                    if ( !string.IsNullOrWhiteSpace( txtDrgTyps.Text.Trim())) {
                        v.RecDrugsTypes = txtDrgTyps.Text.Trim();
                    }
                }
            }
            #endregion


            #region EXCERCISE
            if ( !rblXcrcs.SelectedIndex.Equals(-1)) {
                v.Exercise = rblXcrcs.SelectedValue.Equals("1");
                if ( rblXcrcs.SelectedValue.Equals("1")) {


                    //int ttpw;
                    //if ( int.TryParse( txtXcrcsTmsPrWeek.Text.Trim(), out ttpw)) {
                    //    v.ExerciseTimesPerWeek = ttpw;
                    //}
                    v.ExerciseTimesPerWeek = Convert.ToInt16(ddlXcrcsTmsPrWeek.SelectedItem.Value);

                    if ( !string.IsNullOrWhiteSpace( txtXcrcTypes.Text.Trim())) {
                        v.ExerciseTypes = txtXcrcTypes.Text.Trim();
                    }
                }
            }
            #endregion


            #region DIET
            if ( !rblSpclDiet.SelectedIndex.Equals(-1)) {
                v.SpecialDiet = rblSpclDiet.SelectedValue.Equals("1");
                if ( rblSpclDiet.SelectedValue.Equals("1")) {
                    if ( !string.IsNullOrWhiteSpace( txtSpclDietReasn.Text.Trim())) {
                        v.SpecialDietReason = txtSpclDietReasn.Text.Trim();
                    }
                }
            }
            #endregion


            #region BUCKLUP
            if ( !rblBucklUp.SelectedIndex.Equals(-1)) {
                v.AlwaysBuckledUp = rblBucklUp.SelectedValue.Equals("1");
            }
            #endregion


            #region SUNSCREEN
            if ( !rblWearSuncsren.SelectedIndex.Equals(-1)) {
                v.SunscreenWorn = rblWearSuncsren.SelectedValue.Equals("1");
            }
            #endregion


            #region PROBLEMS PREFORMING DRESSING
            if (!rblPrblmsDrssng.SelectedIndex.Equals(-1)) {
                v.ProblemsDressFeed = rblPrblmsDrssng.SelectedValue.Equals("1");
            }
            #endregion


            #region NEED HLP SHPPNG
            if (!rblNeedHlpShppng.SelectedIndex.Equals(-1)) {
                v.NeedHelpShopping = rblNeedHlpShppng.SelectedValue.Equals("1");
            }
            #endregion


            #region OCCuPTN
            v.Occupation = txtOccptn.Text.Trim(); 
            #endregion



            #region HOM ENVIR
            if ( !rblHomEnvir.SelectedIndex.Equals(-1)) {
                v.HomeEnvironment = GetHomeEnvir( rblHomEnvir);
                if ( v.HomeEnvironment.Equals( HistorySocial._homeEnvir.Other)) {
                    if (!string.IsNullOrWhiteSpace( txtAsstdLivnOthr.Text.Trim())) {
                        v.HomeEnvironmentOther = txtAsstdLivnOthr.Text.Trim();
                    }
                }
            }
            #endregion


            return new Patient().SaveHistorySocial( Convert.ToInt32( Request.QueryString["patientId"].ToString()), v);
        }

        private HistorySocial._homeEnvir GetHomeEnvir( RadioButtonList rbl) {
            if ( !rbl.SelectedIndex.Equals(-1)) {

                //Private home
                if ( rbl.SelectedValue.Equals("0")) {
                    return HistorySocial._homeEnvir.PrivateHome;
                }

                //Assisted Living
                if ( rbl.SelectedValue.Equals("1")) {
                    return HistorySocial._homeEnvir.AssistedLiving;
                }

                //Other
                if ( rbl.SelectedValue.Equals("2")) {
                    return HistorySocial._homeEnvir.Other;
                }

            }
            return HistorySocial._homeEnvir.na;
        }

        private void SaveDemographics( ) {
            var p = new PatientBase()  {
                FName = txtFN.Text.Trim(),
                LName = txtLN.Text.Trim(),
                MName = txtMN.Text.Trim(),
            };
            if ( !txtDOB.Text.Trim().Length.Equals(0)) {
                DateTime dt;
                if ( DateTime.TryParse( txtDOB.Text.Trim(), out dt)) {
                    p.DOB =  dt;
                }
            }
            p.PatientId = Convert.ToInt32( Request.QueryString["patientId"]?.ToString());
            //cntrlPtntDsplInf.DisplayInfo = p.FullName + " " + p.DOB?.ToString("MM/dd/yyyy") + " " + p.Gender;   // as it is useless
            new Patient().SaveDemographic( p); 
        }

        private bool SaveVitals() {
            var v = new Patient();
            v.PatientId = Convert.ToInt32( Request.QueryString["patientId"].ToString());
            v.Gender = (PatientBase._Gender) rblGender.SelectedIndex;
            v.HeightInCM = Common.GetNullableDouble( txtHeight.Text.Trim());
            v.Weight = Common.GetNullableDouble(txtWeight.Text.Trim());
            v.BMI = Common.GetNullableDouble(txtBMI.Text.Trim());
            v.Waist = Common.GetNullableDouble(txtWaist.Text.Trim());

            var _bps = Common.GetNullableInt(txtBpS.Text.Trim());
            var _bpd = Common.GetNullableInt(txtBpD.Text.Trim());
            var bp = new BloodPressure(_bps, _bpd);
            v.BloodPressure = bp;

            v.Temp = Common.GetNullableDouble( txtTemp.Text.Trim());

            return new Patient().SaveVitals(v);
        }

        private bool SavePrvntv() {
            return new Patient().SavePreventive( Convert.ToInt32( Request.QueryString["patientId"].ToString()), ucPreventive.Preventive);
        }



        protected void rblHsptlVst_SelectedIndexChanged(object sender, EventArgs e) {
            pnlHsptlvsts.Visible = rblHsptlVst.SelectedIndex.Equals(1);
        }

        protected void rblTbcc_SelectedIndexChanged(object sender, EventArgs e) {
            pnlTbcc.Visible = rblTbcc.SelectedIndex.Equals(1);
        }

        protected void rblAlchl_SelectedIndexChanged(object sender, EventArgs e) {
            pnlAlchl.Visible = rblAlchl.SelectedIndex.Equals(1);
        }


        protected void rblDrgs_SelectedIndexChanged(object sender, EventArgs e) {
            pnlDrugs.Visible = rblDrgs.SelectedIndex.Equals(1);
        }


        protected void rblXcrcs_SelectedIndexChanged(object sender, EventArgs e) {
            pnlXcrcs.Visible = rblXcrcs.SelectedIndex.Equals(1);
        }

        protected void rblSpclDiet_SelectedIndexChanged(object sender, EventArgs e) {
            pnlSpclDiet.Visible = rblSpclDiet.SelectedIndex.Equals(1);
        }
        protected void rblHomEnvir_SelectedIndexChanged(object sender, EventArgs e) {
            pnlHomEnvir.Visible = rblHomEnvir.SelectedIndex.Equals(2);
        }


        protected void btnAddOffcVst_Click(object sender, EventArgs e) {
            if (
                txtOffcVstReason.Text.Trim().Length + 
                txtFclt.Text.Trim().Length + 
                txtPhscn.Text.Trim().Length+ 
                txtOffcVstDt.Text.Trim().Length != 0)   {

                var patientId = Convert.ToInt32( Request.QueryString["patientId"].ToString());
                var reason = txtOffcVstReason.Text.Trim();
                var facility = txtFclt.Text.Trim();
                var phscn = txtPhscn.Text.Trim();

                var offcVstDt = new DateTime();
                if ( DateTime.TryParse(txtOffcVstDt.Text.Trim(), out offcVstDt)) {
                    new Patient().AddHospitalVisit( patientId, reason, facility, phscn, offcVstDt);
                } else {
                    new Patient().AddHospitalVisit( patientId, reason, facility, phscn, null);
                }  
                grdHsptlVsts.DataBind();
                rblHsptlVst.Enabled = false;
            }

            //Toast("Saved!");
        }


        protected void btnAddAllrgy_Click(object sender, EventArgs e)  {
            if ( txtAllrgy.Text.Trim().Length +
                txtReactn.Text.Trim().Length != 0)  {

                var patientId = Convert.ToInt32( Request.QueryString["patientId"].ToString());
                var allrg = txtAllrgy.Text.Trim();
                var reactn = txtReactn.Text.Trim();

                new Patient().AddAllergy( patientId, allrg, reactn);

                grdAllrgs.DataBind();
                rblAllrgs.Enabled = false;
            }

            //Toast("Saved!");
        }

        protected void btnAddPrvdr_Click(object sender, EventArgs e)  {
            if ( txtPrvdrNm.Text.Trim().Length +
                txtTypeOfCar.Text.Trim().Length + 
                txtDateEnded.Text.Trim().Length  != 0)  {

                var patientId = Convert.ToInt32( Request.QueryString["patientId"].ToString());
                var providerName = txtPrvdrNm.Text.Trim();
                var typeOfCare = txtTypeOfCar.Text.Trim();

                var dateEnded = new DateTime();
                if (DateTime.TryParse( txtDateEnded.Text.Trim(), out dateEnded)) {
                    new Patient().AddProvider(patientId, providerName, typeOfCare, dateEnded);
                } else {
                    new Patient().AddProvider(patientId, providerName, typeOfCare, null);
                }

                grdPrvdrs.DataBind();
                rblSeengOthrPrvdrs.Enabled = false;
            }

            //Toast("Saved!");
        }

        protected void rblAllrgs_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlAllrgs.Visible = rblAllrgs.SelectedIndex.Equals(1);
        }

        protected void rblSeengOthrPrvdrs_SelectedIndexChanged(object sender, EventArgs e)
        {
            pnlPrvdrs.Visible = rblSeengOthrPrvdrs.SelectedIndex.Equals(1);
        }

        protected void stpDmgrphc_Deactivate(object sender, EventArgs e) {
            SaveDemographics();
            ScriptManager.RegisterStartupScript(updtPnlMaster, updtPnlMaster.GetType(), "scrptSv", "toastr.success(' Demographics Saved!', 'AWV')", true);
        }

        protected void stpVitals_Deactivate(object sender, EventArgs e) {
            SaveVitals();
            ScriptManager.RegisterStartupScript(updtPnlMaster, updtPnlMaster.GetType(), "scrptSv", "toastr.success('Vitals Saved!', 'AWV')", true);
        }


        protected void btnPDF_Click( object sender, EventArgs e) {

            string dataDir = Server.MapPath("") + @"\\Temp\";

            renderPdf( dataDir + "2018_3_11_16_3_33.pdf");
            return;


            var InputHtml = dataDir + "input.html";
            using ( var fs = File.Create( InputHtml))
            using ( var sw = new StreamWriter( fs)) {
                sw.Write(
                @"<style>
                .st
                { color: green; }
                </style>
                <div id=id1>Aspose.Html rendering Text in Black Color</div>
                <div id=id2 class=''st''>Aspose.Html rendering Text in Green Color</div>
                <div id=id3 class=''st'' style='color: blue;'>Aspose.Html rendering Text in Blue Color</div>
                <div id=id3 class=''st'' style='color: red;'><font face='Arial'>Aspose.Html rendering Text in Red Color</font></div>");
            }

            var Resultant_output = dataDir + 
                    DateTime.Now.Year.ToString() + "_" + 
                    DateTime.Now.Month.ToString() + "_" +
                    DateTime.Now.Day.ToString() + "_" +
                    DateTime.Now.Hour.ToString() + "_" + 
                    DateTime.Now.Minute.ToString() + "_" +
                    DateTime.Now.Second.ToString() + ".pdf";

            // Create PdfRendering Options object
            var pdf_options = new PdfRenderingOptions();

            // The PageSetup also provides different properties i.e. FirstPage, LastPage, LeftPage, RightPage and they are used to setup (PageSize, Margin) for every page.
            // In most cases, usage of setup any page is enough, but in some complicated cases, you may need to fine tune page settings. It can be done either by CSS styles or by using rendering options.
            // the size for drawing is in pixels
            pdf_options.PageSetup.AnyPage = new Aspose.Html.Drawing.Page( new Aspose.Html.Drawing.Size( 400, 100));
            
            // Instantiate PdfDevice object while passing PdfRenderingOptions and resultant file path as arguments
            using ( var pdf_device = new PdfDevice( pdf_options, Resultant_output))
                
            // Create HtmlRenderer object
            using ( var renderer = new HtmlRenderer())
                
            // Create HtmlDocument instance while passing path of already created HTML file
            using ( var html_document = new HTMLDocument( InputHtml)) {
                // Render the output using HtmlRenderer
                renderer.Render( pdf_device, html_document);
            }


            renderPdf( Resultant_output);



        }

        protected void renderPdf( string sFile) {

            var docSize = new FileInfo(sFile).Length;

            Response.ClearContent();
            Response.ContentType = "application/pdf";
            Response.AddHeader("Content-Disposition", "inline; filename=" + sFile);
            Response.AddHeader("Content-Length", docSize.ToString());
            Response.BinaryWrite( File.ReadAllBytes( sFile));
            Response.End();

        }


    }

}