﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace awv {
    public class Screening  {

        #region DEPRESSION
        public bool? Depressed { get; set; }
        public bool? LittleInterest { get; set; }
        #endregion

        #region FUNCTION

        public bool? Unsteady { get; set; }

        public bool? LivesAlone { get; set; }

        public bool? NeedHelpWithMeals { get; set; }
        #endregion

        #region HEARING LOSS
        public bool? HearingDifficulties { get; set; }
        public bool? StrainedHearing { get; set; }
        #endregion

        #region HOME SAFETY
        public bool? HallwayRugs { get; set; }
        public bool? LackGrabBars { get; set; }
        #endregion

        #region MINI-COG
        public int? WordListVersion { get; set; }

        public int? PersonAnswerA { get; set; }

        public int? PersonAnswerB { get; set; }

        public int? PersonAnswerC { get; set; }

        public int? ScoringWordRecall { get; set; }

        public int? ScoringClockDraw { get; set; }
        #endregion

        public Preventive Preventive { get; set; }


    }
}