﻿using System;

namespace awv {

    public class PrvntvBase {

        public DateTime? DateOfLastService { get; set; }

        public DateTime? DueDate { get; set; }

        public bool? Need { get; set; }

    }

    public class Preventive {

        public AbdmnlAortcAnursm AbdmnlAortcAnursm { get; set; }

        public AlchlMisuseAndCnslng AlchlMisuseAndCnslng  { get; set; }

        public BonDensitMeasrmnt BonDensitMeasrmnt  { get; set; }


        public CardiovasclrScrenngs CardiovasclrScrenngs  {get; set;  }


        public ColorectalCancerStoolSampl ColorectalCancerStoolSampl   { get; set; }


        public ColorectalCancerFlxblSigmdscp ColorectalCancerFlxblSigmdscp   { get; set; }


        public ColorectalCancerScrnngColonscp ColorectalCancerScrnngColonscp   { get; set; }


        public Depression Depression   { get; set; }


        public DiabetisScrenng DiabetisScrenng   {get; set;  }

        public Glaucoma Glaucoma   { get; set; }

        public HIV HIV   { get; set; }

        public Mammogrm Mammogrm   {get; set;  }

        public MedNutrcnThrpy MedNutrcnThrpy   { get; set;}

        public ObestyAndCounslg ObestyAndCounslg   { get; set;}

        public PapSmr PapSmr   { get; set; }

        public ProsttCncr ProsttCncr  { get; set; }

        public TobaccUseCounslg TobaccUseCounslg   { get; set; }

        public Vaccine_HepB Vaccine_HepB   { get; set;}

        public Vaccine_Flu Vaccine_Flu   { get; set;}

        public Vaccine_Pneumo Vaccine_Pneumo   { get; set;}

        public NextAWV NextAWV   { get; set; }

        //public static explicit operator Preventive(AbdmnlAortcAnursm v)
        //{
        //    throw new NotImplementedException();
        //}
    }




    public class AbdmnlAortcAnursm : PrvntvBase { }

    public class AlchlMisuseAndCnslng : PrvntvBase { }

    public class BonDensitMeasrmnt : PrvntvBase { }


    public class CardiovasclrScrenngs : PrvntvBase { }


    public class ColorectalCancerStoolSampl : PrvntvBase { }


    public class ColorectalCancerFlxblSigmdscp : PrvntvBase { }


    public class ColorectalCancerScrnngColonscp : PrvntvBase { }


    public class Depression : PrvntvBase { }


    public class DiabetisScrenng : PrvntvBase { }

    [Serializable]
    public class Glaucoma : PrvntvBase { }

    public class HIV : PrvntvBase { }

    public class Mammogrm : PrvntvBase { }

    public class MedNutrcnThrpy : PrvntvBase { }

    public class ObestyAndCounslg : PrvntvBase { }

    public class PapSmr : PrvntvBase { }

    public class ProsttCncr : PrvntvBase { }

    public class TobaccUseCounslg : PrvntvBase { }

    public class Vaccine_HepB : PrvntvBase { }

    public class Vaccine_Flu : PrvntvBase { }

    public class Vaccine_Pneumo : PrvntvBase { }

    public class NextAWV : PrvntvBase { }




}