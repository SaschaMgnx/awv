﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace awv {

    public class BloodPressure {

        public BloodPressure( int? _Systolic, int? _Diastolic) {
            Systolic = _Systolic;
            Diastolic = _Diastolic;
        }

        public int? Systolic { get; set; }

        public int? Diastolic { get; set; }

    }
}