﻿using System;
using System.Globalization;
using System.Web.UI;

namespace awv
{
    public partial class Preventive1 : UserControl {

        protected void Page_Load( object sender, EventArgs e) { }

        public Preventive Preventive {
            get {

                var p = new Preventive();

                var aaa = new AbdmnlAortcAnursm();
                aaa.Need = chkAbdmnl.Checked;
                aaa.DateOfLastService = Common.GetNullableDateTimeValue( txtAbdmnlLastSrvcDt.Text);
                aaa.DueDate = Common.GetNullableDateTimeValue( txtAbdmnlDueDt.Text);
                p.AbdmnlAortcAnursm = aaa;

                var amc = new AlchlMisuseAndCnslng();
                amc.Need = chkAlchl.Checked;
                amc.DateOfLastService = Common.GetNullableDateTimeValue(txtAlchlLastSrvsDt.Text);
                amc.DueDate = Common.GetNullableDateTimeValue(txtAlchlDueDt.Text);
                p.AlchlMisuseAndCnslng = amc;

                var bdm = new BonDensitMeasrmnt();
                bdm.Need = chkBonDenst.Checked;
                bdm.DateOfLastService = Common.GetNullableDateTimeValue(txtBonDenstSrvsDt.Text);
                bdm.DueDate = Common.GetNullableDateTimeValue(txtBonDenstDueDt.Text);
                p.BonDensitMeasrmnt = bdm;

                var cvs = new CardiovasclrScrenngs();
                cvs.Need = chkCardio.Checked;
                cvs.DateOfLastService = Common.GetNullableDateTimeValue(txtCardioSrvcDt.Text);
                cvs.DueDate = Common.GetNullableDateTimeValue(txtCardioDueDt.Text);
                p.CardiovasclrScrenngs = cvs;

                var ccss = new ColorectalCancerStoolSampl();
                ccss.Need = chkColorctCncrStool.Checked;
                ccss.DateOfLastService = Common.GetNullableDateTimeValue(txtColorctlCncrStoolSrvcDt.Text);
                ccss.DueDate = Common.GetNullableDateTimeValue(txtColorctlCncrStoolDueDt.Text);
                p.ColorectalCancerStoolSampl = ccss;

                var ccfs = new ColorectalCancerFlxblSigmdscp();
                ccfs.Need = chkColorctCncrSigmoid.Checked;
                ccfs.DateOfLastService = Common.GetNullableDateTimeValue(txtColorctCncrSigmoidSrvcDt.Text);
                ccfs.DueDate = Common.GetNullableDateTimeValue(txtColorctCncrSigmoidDueDt.Text);
                p.ColorectalCancerFlxblSigmdscp = ccfs;

                var ccsc = new ColorectalCancerScrnngColonscp();
                ccsc.Need = chkColorctCncrColonscp.Checked;
                ccsc.DateOfLastService = Common.GetNullableDateTimeValue(txtColorctCncrColonscpSrvcDt.Text);
                ccsc.DueDate = Common.GetNullableDateTimeValue(txtColorctCncrColonscpSrvcDt.Text);
                p.ColorectalCancerScrnngColonscp = ccsc;

                var dprs = new Depression();
                dprs.Need = chkDeprssn.Checked;
                dprs.DateOfLastService = Common.GetNullableDateTimeValue(txtDeprssnSrvcDt.Text);
                dprs.DueDate = Common.GetNullableDateTimeValue(txtDeprssnDueDt.Text);
                p.Depression = dprs;

                var ds = new DiabetisScrenng();
                ds.Need = chkDiabets.Checked;
                ds.DateOfLastService = Common.GetNullableDateTimeValue(txtDiabetSrvcDt.Text);
                ds.DueDate = Common.GetNullableDateTimeValue(txtDiabetDueDt.Text);
                p.DiabetisScrenng = ds;

                var gl = new Glaucoma();
                gl.Need = chkGlaucom.Checked;
                gl.DateOfLastService = Common.GetNullableDateTimeValue(txtGlaucomSrvsDt.Text);
                gl.DueDate = Common.GetNullableDateTimeValue(txtGlaucomDueDt.Text);
                p.Glaucoma = gl;

                var h = new HIV();
                h.Need = chkHiv.Checked;
                h.DateOfLastService = Common.GetNullableDateTimeValue(txtHivSrvcDt.Text);
                h.DueDate = Common.GetNullableDateTimeValue(txtHivDueDt.Text);
                p.HIV = h;

                var m = new Mammogrm();
                m.Need = chkMammo.Checked;
                m.DateOfLastService = Common.GetNullableDateTimeValue(txtMammoSrvsDt.Text);
                m.DueDate = Common.GetNullableDateTimeValue(txtMammoDueDt.Text);
                p.Mammogrm = m;

                var mnt = new MedNutrcnThrpy();
                mnt.Need = chkMedNutr.Checked;
                mnt.DateOfLastService = Common.GetNullableDateTimeValue(txtMedNutrSrvsDt.Text);
                mnt.DueDate = Common.GetNullableDateTimeValue(txtMedNutrDueDt.Text);
                p.MedNutrcnThrpy = mnt;

                var oac = new ObestyAndCounslg();
                oac.Need = chkObesit.Checked;
                oac.DateOfLastService = Common.GetNullableDateTimeValue(txtObesSrvsDt.Text);
                oac.DueDate = Common.GetNullableDateTimeValue(txtObesDueDt.Text);
                p.ObestyAndCounslg = oac;

                var ps = new PapSmr();
                ps.Need = chkPap.Checked;
                ps.DateOfLastService = Common.GetNullableDateTimeValue(txtPapSrvsDt.Text);
                ps.DueDate = Common.GetNullableDateTimeValue(txtPapDueDt.Text);
                p.PapSmr = ps;

                var pc = new ProsttCncr();
                pc.Need = chkProstatCncr.Checked;
                pc.DateOfLastService = Common.GetNullableDateTimeValue(txtPrstCncrSrvsDt.Text);
                pc.DueDate = Common.GetNullableDateTimeValue(txtPrstCncrDueDt.Text);
                p.ProsttCncr = pc;

                var tuc = new TobaccUseCounslg();
                tuc.Need = chkTobacCounsl.Checked;
                tuc.DateOfLastService = Common.GetNullableDateTimeValue(txtTobacSrvsDt.Text);
                tuc.DueDate = Common.GetNullableDateTimeValue(txtTobacDueDt.Text);
                p.TobaccUseCounslg = tuc;

                var vhb = new Vaccine_HepB();
                vhb.Need = chkHepB.Checked;
                vhb.DateOfLastService = Common.GetNullableDateTimeValue(txtHepBSrvsDt.Text);
                vhb.DueDate = Common.GetNullableDateTimeValue(txtHepBDueDt.Text);
                p.Vaccine_HepB = vhb;

                var vf = new Vaccine_Flu();
                vf.Need = chkFlu.Checked;
                vf.DateOfLastService = Common.GetNullableDateTimeValue(txtFluSrvcDt.Text);
                vf.DueDate = Common.GetNullableDateTimeValue(txtFluDueDt.Text);
                p.Vaccine_Flu = vf;

                var vp = new Vaccine_Pneumo();
                vp.Need = chkPneum.Checked;
                vp.DateOfLastService = Common.GetNullableDateTimeValue(txtPneumSrvcDt.Text);
                vp.DueDate = Common.GetNullableDateTimeValue(txtPneumDueDt.Text);
                p.Vaccine_Pneumo = vp;

                var nav = new NextAWV();
                nav.Need = chkNextAWV.Checked;
                nav.DateOfLastService = Common.GetNullableDateTimeValue(txtNextAwvSrvsDt.Text);
                nav.DueDate = Common.GetNullableDateTimeValue(txtNextAwvDueDt.Text);
                p.NextAWV = nav;


                return p;
            }
            set {

                var p = value;
                if (p != null) {

                    if (p.AbdmnlAortcAnursm != null) {
                        chkAbdmnl.Checked = (bool)p.AbdmnlAortcAnursm.Need;
                        txtAbdmnlLastSrvcDt.Text = p.AbdmnlAortcAnursm.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtAbdmnlDueDt.Text = p.AbdmnlAortcAnursm.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.AlchlMisuseAndCnslng != null) {
                        chkAlchl.Checked = (bool)p.AlchlMisuseAndCnslng.Need;
                        txtAlchlLastSrvsDt.Text = p.AlchlMisuseAndCnslng.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtAlchlDueDt.Text = p.AlchlMisuseAndCnslng.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }


                    if (p.BonDensitMeasrmnt != null) {
                        chkBonDenst.Checked = (bool)p.BonDensitMeasrmnt.Need;
                        txtBonDenstSrvsDt.Text = p.BonDensitMeasrmnt.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtBonDenstDueDt.Text = p.BonDensitMeasrmnt.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }


                    if (p.CardiovasclrScrenngs != null) {
                        chkCardio.Checked = (bool)p.CardiovasclrScrenngs.Need;
                        txtCardioSrvcDt.Text = p.CardiovasclrScrenngs.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtCardioDueDt.Text = p.CardiovasclrScrenngs.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.ColorectalCancerStoolSampl != null)
                    {
                        chkColorctCncrStool.Checked = (bool)p.ColorectalCancerStoolSampl.Need;
                        txtColorctlCncrStoolSrvcDt.Text = p.ColorectalCancerStoolSampl.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtColorctlCncrStoolDueDt.Text = p.ColorectalCancerStoolSampl.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.ColorectalCancerFlxblSigmdscp != null)
                    {
                        chkColorctCncrSigmoid.Checked = (bool)p.ColorectalCancerFlxblSigmdscp.Need;
                        txtColorctCncrSigmoidSrvcDt.Text = p.ColorectalCancerFlxblSigmdscp.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtColorctCncrSigmoidDueDt.Text = p.ColorectalCancerFlxblSigmdscp.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }


                    if (p.ColorectalCancerScrnngColonscp != null)
                    {
                        chkColorctCncrColonscp.Checked = (bool)p.ColorectalCancerScrnngColonscp.Need;
                        txtColorctCncrColonscpSrvcDt.Text = p.ColorectalCancerScrnngColonscp.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtColorctCncrColonscpSrvcDt.Text = p.ColorectalCancerScrnngColonscp.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }


                    if (p.Depression != null)
                    {
                        chkDeprssn.Checked = (bool)p.Depression.Need;
                        txtDeprssnSrvcDt.Text = p.Depression.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtDeprssnDueDt.Text = p.Depression.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }


                    if (p.DiabetisScrenng != null)
                    {
                        chkDiabets.Checked = (bool)p.DiabetisScrenng.Need;
                        txtDiabetSrvcDt.Text = p.DiabetisScrenng.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtDiabetDueDt.Text = p.DiabetisScrenng.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }


                    if (p.Glaucoma != null)
                    {
                        chkGlaucom.Checked = (bool)p.Glaucoma.Need;
                        txtGlaucomSrvsDt.Text = p.Glaucoma.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtGlaucomDueDt.Text = p.Glaucoma.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.HIV != null)
                    {
                        chkHiv.Checked = (bool)p.HIV.Need;
                        txtHivSrvcDt.Text = p.HIV.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtHivDueDt.Text = p.HIV.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }


                    if (p.Mammogrm != null)
                    {
                        chkMammo.Checked = (bool)p.Mammogrm.Need;
                        txtMammoSrvsDt.Text = p.Mammogrm.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtMammoDueDt.Text = p.Mammogrm.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }


                    if (p.MedNutrcnThrpy != null)
                    {
                        chkMedNutr.Checked = (bool)p.MedNutrcnThrpy.Need;
                        txtMedNutrSrvsDt.Text = p.MedNutrcnThrpy.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtMedNutrDueDt.Text = p.MedNutrcnThrpy.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.ObestyAndCounslg != null)
                    {
                        chkObesit.Checked = (bool)p.ObestyAndCounslg.Need;
                        txtObesSrvsDt.Text = p.ObestyAndCounslg.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtObesDueDt.Text = p.ObestyAndCounslg.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.PapSmr != null)
                    {
                        chkPap.Checked = (bool)p.PapSmr.Need;
                        txtPapSrvsDt.Text = p.PapSmr.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtPapDueDt.Text = p.PapSmr.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.ProsttCncr != null)
                    {
                        chkProstatCncr.Checked = (bool)p.ProsttCncr.Need;
                        txtPrstCncrSrvsDt.Text = p.ProsttCncr.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtPrstCncrDueDt.Text = p.ProsttCncr.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.TobaccUseCounslg != null)
                    {
                        chkTobacCounsl.Checked = (bool)p.TobaccUseCounslg.Need;
                        txtTobacSrvsDt.Text = p.TobaccUseCounslg.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtTobacDueDt.Text = p.TobaccUseCounslg.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.Vaccine_HepB != null)
                    {
                        chkHepB.Checked = (bool)p.Vaccine_HepB.Need;
                        txtHepBSrvsDt.Text = p.Vaccine_HepB.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtHepBDueDt.Text = p.Vaccine_HepB.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.Vaccine_Flu != null)
                    {
                        chkFlu.Checked = (bool)p.Vaccine_Flu.Need;
                        txtFluSrvcDt.Text = p.Vaccine_Flu.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtFluDueDt.Text = p.Vaccine_Flu.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.Vaccine_Pneumo != null)
                    {
                        chkPneum.Checked = (bool)p.Vaccine_Pneumo.Need;
                        txtPneumSrvcDt.Text = p.Vaccine_Pneumo.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtPneumDueDt.Text = p.Vaccine_Pneumo.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }

                    if (p.NextAWV != null)
                    {
                        chkNextAWV.Checked = (bool)p.NextAWV.Need;
                        txtNextAwvSrvsDt.Text = p.NextAWV.DateOfLastService?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                        txtNextAwvDueDt.Text = p.NextAWV.DueDate?.ToString("MM/dd/yyyy", CultureInfo.InvariantCulture);
                    }




                }
            }
        }



        

    }
}