﻿using System.Web.UI;

namespace awv.Account
{
    public partial class ResetPasswordConfirmation : Page
    {
    }
}