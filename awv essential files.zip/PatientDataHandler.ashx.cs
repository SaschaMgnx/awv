﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Script.Serialization;

namespace awv {

    public class PatientDataHandler : IHttpHandler {

        public void ProcessRequest( HttpContext context) {

            int displayLength = int.Parse(context.Request["iDisplayLength"]);
            int displayStart = int.Parse(context.Request["iDisplayStart"]);
            int sortCol = int.Parse(context.Request["iSortCol_0"]);
            string sortDir = context.Request["sSortDir_0"];
            string search = context.Request["sSearch"];

            string cs = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
            var patientsList = new List<PatientSearchX>();
            int filteredCount = 0;
            using (var con = new SqlConnection(cs)){
                var cmd = new SqlCommand("GetPatientsX", con);
                cmd.CommandType = CommandType.StoredProcedure;

                var paramDisplayLength = new SqlParameter() {
                    ParameterName = "@DisplayLength",
                    Value = displayLength
                };
                cmd.Parameters.Add(paramDisplayLength);

                var paramDisplayStart = new SqlParameter() {
                    ParameterName = "@DisplayStart",
                    Value = displayStart
                };
                cmd.Parameters.Add(paramDisplayStart);

                var paramSortCol = new SqlParameter() {
                    ParameterName = "@SortCol",
                    Value = sortCol
                };
                cmd.Parameters.Add(paramSortCol);

                var paramSortDir = new SqlParameter() {
                    ParameterName = "@SortDir",
                    Value = sortDir
                };
                cmd.Parameters.Add(paramSortDir);

                var paramSearchString = new SqlParameter() {
                    ParameterName = "@Search",
                    Value = string.IsNullOrEmpty(search) ? null : search
                };
                cmd.Parameters.Add( paramSearchString);

                con.Open();
                var rdr = cmd.ExecuteReader();
                while (rdr.Read()) {
                    var patient = new PatientSearchX();
                    patient.PatientId = Convert.ToInt32( rdr["PatientId"]);
                    filteredCount = Convert.ToInt32( rdr["TotalCount"]);
                    patient.PatientName = rdr["FullName"].ToString();
                    patient.PatientGender = rdr["Gender"].ToString();
                    if ( !string.IsNullOrEmpty( rdr["Age"].ToString())) {
                        patient.PatientAge = Convert.ToInt16(rdr["Age"].ToString());
                    }
                    patientsList.Add( patient);
                }
            }

            var result = new {
                iTotalRecords = GetPatientTotalCount(),
                iTotalDisplayRecords = filteredCount,
                aaData = patientsList
            };

            var js = new JavaScriptSerializer();
            context.Response.Write( js.Serialize( result));
        }

        private int GetPatientTotalCount() {
            int totalPatientCount = 0;
            string cs = ConfigurationManager.ConnectionStrings["cnn"].ConnectionString;
            using (var con = new SqlConnection(cs)) {
                var cmd = new SqlCommand("select count(*) from Patient", con);
                con.Open();
                totalPatientCount = (int)cmd.ExecuteScalar();
            }
            return totalPatientCount;
        }

        public bool IsReusable {
            get {
                return false;
            }
        }
    }
}