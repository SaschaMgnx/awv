﻿using Aspose.Pdf;
using Newtonsoft.Json;
using System;
using System.IO;
using System.Reflection;
using System.Text;
using Newtonsoft.Json.Linq;

namespace awv {

    public partial class PdfReport : System.Web.UI.Page {

        protected void Page_Load( object sender, EventArgs e) {
            if ( !(Request.QueryString["patientId"] == null)) {
                int patientId;
                if ( int.TryParse( Request.QueryString["patientId"], out patientId)) {
                    createHtm( patientId, Server.MapPath("") + @"\\Temp\");
                    createPDF( patientId, Server.MapPath("") + @"\\Temp\");
                }
            }
        }

        private void createHtm( int patientId, string templatePath) {
            var p = new Patient().Get( patientId);
            if (p != null) {
                var contents = File.ReadAllText( templatePath + "PatientReport.html");

                var sss = "<table>" + ReadPropertiesRecursive( typeof(Patient)) + "</table>"; 
                Console.WriteLine( sss);

                string output = JsonConvert.SerializeObject( p);
                //Console.WriteLine( output);

                //dynamic dynJson = JsonConvert.DeserializeObject(output);
                //Console.WriteLine();
                //foreach (var item in dynJson) {
                //    Console.WriteLine(item.ToString());
                //}

                var s = new StringBuilder();
                var obj = JObject.Parse( output);
                foreach (var x in obj) {
                    string name = x.Key;
                    JToken value = x.Value;
                    //if ( value.Type == (JTokenType)typeof(Object))
                    //{
                    //    s.Append( value.Path + ";");
                    //}
                    //else
                    {
                        s.Append( value.Path + ";");
                    }
                    
                }

                Console.WriteLine(s.ToString());

            }
        }

        private static string ReadPropertiesRecursive( Type type) {
            if ( type.Name.Equals("String")) {
                return string.Empty;
            }
            var r = new StringBuilder();
            foreach ( PropertyInfo p in type.GetProperties()) {
                if ( p.PropertyType.IsClass) {
                    r.Append( p.Name + ":" + ReadPropertiesRecursive( p.PropertyType) + "");
                } else {
                    //if (!p.CanRead) {
                    r/*.Append("<li>" + p.Name + "; write: " + p.CanWrite + "; read:" + p.CanRead + "</li>");*/
                    .Append("<tr><td>" + p.Name + "</td><td>" + p.CanWrite + "</td><td>" + p.CanRead + "</td></tr>");
                    //}
                }
            }
            return r.ToString();
        }



        private string fileContents( string textFilePath) {
 
            return "";
        }

        private void createPDF(int patientId, string path) {
            try {
                var options = new HtmlLoadOptions();
                options.CustomLoaderOfExternalResources = new LoadOptions.ResourceLoadingStrategy( samePictureLoader);

                var pdfDocument = new Document( path + "PatientReport.html", options);
                pdfDocument.Save( path + patientId + ".pdf");
            } catch (Exception ex) {
                Console.WriteLine( ex.Message);
                throw ex;
            }
        }
        private static LoadOptions.ResourceLoadingResult samePictureLoader( string resourceURIb) {
            byte[] resultBytes = File.ReadAllBytes( "Images/aspose-logo.jpg");
            LoadOptions.ResourceLoadingResult result = new LoadOptions.ResourceLoadingResult(resultBytes);
            return result;
        }

    }
}