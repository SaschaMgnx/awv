﻿using System;
using System.Collections.Generic;
using System.Web.UI;

namespace awv {

    public partial class _Default : Page {

        protected void Page_Load(object sender, EventArgs e) {







            return;









            var p = new Patient().Get( 40082);
            Console.WriteLine();


            var hf = new HistoryFamily( 8, 11);
            var hfL = new List<HistoryFamily>();
            hfL.Add(hf);
            new Patient().SaveHistoryFamily( 20071, hfL);



            var patient = new Patient();
            patient.FName = "Griz0lda";
            patient.LName = "Siegelz";
            patient.MName = "X.";
            //patient.DOB = new DateTime( 1960, 1, 9);
            patient.Gender = Patient._Gender.Female;
            patient.HeightInCM = 179.45;
            patient.Weight = 180.9;
            patient.BMI = 24.4;
            patient.Waist = 33.99;
            patient.Temp = 100.5;
            patient.BloodPressure = new BloodPressure( 130, 75);


            #region HISTORY SOCIAL

            var hs = new HistorySocial();

            hs.TobaccoEverUsed = null;
            //hs.TobaccoKind = HistorySocial._tobaccoKind.na;
            hs.TobaccoTimesPerWeek = 20;


            hs.AlcoholTimesPerWeek = 1;
            hs.AlcoholUse = true;

            hs.RecDrugsUse = true;
            hs.RecDrugsTypes = "Marja Ivanovna";

            hs.Exercise = true;
            hs.ExerciseTimesPerWeek = 2;
            hs.ExerciseTypes = "Treadmill, elliptical";

            hs.SpecialDiet = true;
            hs.SpecialDietReason = "pheeelin' better this way";

            hs.AlwaysBuckledUp = true;
            hs.SunscreenWorn = true;

            hs.ProblemsDressFeed = false;
            hs.NeedHelpShopping = false;

            hs.Occupation = "beautician";

            hs.HomeEnvironment = HistorySocial._homeEnvir.PrivateHome;
            hs.HomeEnvironment = HistorySocial._homeEnvir.Other;
            hs.HomeEnvironmentOther = "vse udobstva"; 

            patient.HistorySocial = hs;

            #endregion


            #region HISTORY FAMILY

            var getFamilyMemberIndex = new Lookup("FamilyMembers").Listing;
            var getDiseaseIndex = new Lookup("Disease").Listing;

            //var hf = new HistoryFamily();
            //hf.Deceased = HistoryFamily.FamilyMembers.Aunts;
            //hf.Deceased = HistoryFamily.FamilyMembers.Father;
            //hf.Hypertension = HistoryFamily.FamilyMembers.Sons;
            //hf.OtherCancer = HistoryFamily.FamilyMembers.Self;
            //hf.Stroke = HistoryFamily.FamilyMembers.Mother;

            //patient.HistoryFamily = hf;

            #endregion


            //screening 
            var screening = new Screening();
            screening.Depressed = true;
            screening.HearingDifficulties = true;
            patient.Screening = screening;


            var nPat = new Patient().Add( patient);


            Console.WriteLine( patient.ToString());


            Response.Write( new db().PatientCount());


        }
    }
}