﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace awv
{
    public class Allergy
    {

        public Allergy(string descr, string reaction)
        {
            Descr = descr;
            Reaction = reaction;
        }

        public string Descr { get; set; }

        public string Reaction { get; set; }

    }
}