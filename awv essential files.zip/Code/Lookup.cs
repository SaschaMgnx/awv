﻿using System;
using System.Collections;
using Microsoft.Practices.EnterpriseLibrary.Caching;
using Microsoft.Practices.EnterpriseLibrary.Caching.Expirations;
using System.Configuration;
using System.Collections.Generic;

namespace awv
{
    public class Lookup  {

        ICacheManager cache = CacheFactory.GetCacheManager("Cache Manager");

        public Lookup(string listing) {
            _listing = listing;
        }

        private string _listing;

        //public Hashtable Listing {
        //    get {
        //        var ht = new Hashtable();
        //        if (cache.Contains(_listing)) {
        //            return (Hashtable)cache.GetData(_listing);
        //        } else  {
        //            ht = new db().GetLookupValues(_listing);
        //            cache.Add(
        //                    _listing,
        //                    ht,
        //                    CacheItemPriority.Normal,
        //                    null,
        //                    new AbsoluteTime(DateTime.Now.AddMinutes(Convert.ToInt16(ConfigurationManager.AppSettings["LookupCacheExpirationInMinutes"]))));
        //            return ht;
        //        }
        //    }
        //}


        public SortedDictionary<int, string> Listing {
            get {
                var ht = new SortedDictionary<int, string>();
                if (cache.Contains(_listing)) {
                    return (SortedDictionary<int, string>)cache.GetData(_listing);
                } else {
                    ht = new db()._GetLookupValues(_listing);
                    cache.Add(
                            _listing,
                            ht,
                            CacheItemPriority.Normal,
                            null,
                            new AbsoluteTime(DateTime.Now.AddMinutes(Convert.ToInt16(ConfigurationManager.AppSettings["LookupCacheExpirationInMinutes"]))));
                    return ht;
                }
            }
        }


    }
}