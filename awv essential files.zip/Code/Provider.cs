﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace awv
{
    public class Provider
    {
        public string NameAndSpecialty { get; set; }
        public string TypeOfCare { get; set; }
        public DateTime? DateEnded { get; set; }
    }
}