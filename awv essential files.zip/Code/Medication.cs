﻿using System;

namespace awv {
    public class Medication
    {
        public string Name { get; set; }

        public string Frequency { get; set; }

        public DateTime? DateStarted { get; set; }

        public DateTime? DateEnded { get; set; }
    }
}