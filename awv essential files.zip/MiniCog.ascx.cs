﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace awv {
    public partial class MiniCog : UserControl {

        public int? WordListVersion {
            get {
                return Common.GetNullableInt( ddlWrdLstVrsn.SelectedItem.Value);
            }
            set {
                if ( value != null) {
                    ddlWrdLstVrsn.Items.FindByValue( value.ToString()).Selected = true; 
                }
            }
        }

        public int? AnswerA {
            get {
                return Common.GetNullableInt16( txtAnsw1.Text);
            }
            set { txtAnsw1.Text = value.ToString(); }
        }

        public int? AnswerB {
            get { return Common.GetNullableInt16(txtAnsw2.Text); }
            set { txtAnsw2.Text = value.ToString(); }
        }

        public int? AnswerC {
            get { return Common.GetNullableInt16(txtAnsw3.Text); }
            set { txtAnsw3.Text = value.ToString(); }
        }

        //ddWrdRcll
        public int? ScoringWordRecall {
            get { return Common.GetNullableInt(ddWrdRcll.SelectedItem.Value); }
            set {
                if (value != null) {
                    ddWrdRcll.Items.FindByValue(value.ToString()).Selected = true;
                }
            }
        }

        //ddClckDrw
        public int? ScoringClockDraw {
            get { return Common.GetNullableInt(ddClckDrw.SelectedItem.Value); }
            set {
                if (value != null) {
                    ddClckDrw.Items.FindByValue(value.ToString()).Selected = true;
                }
            }
        }

    }
}