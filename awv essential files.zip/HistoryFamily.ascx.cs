﻿using System;
using System.Collections.Generic;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace awv {
    public partial class HistoryFamily1 : UserControl {
        protected void Page_Load(object sender, EventArgs e) {

        }

        public void LoadControlOptions() {
            if (!IsPostBack) {
                var familyMemberIndex = new Lookup("FamilyMembers").Listing;
                var diseaseIndex = new Lookup("Disease").Listing;
                foreach (var i in familyMemberIndex) {
                    if (!i.Key.Equals(0)) {
                        foreach (var z in diseaseIndex) {
                            var li = new ListItem() {
                                Text = string.Empty,
                                Value = i.Key.ToString() + "." + z.Key.ToString(),
                            };
                            switch (z.Key) {
                                case 10: chkDeceased.Items.Add(li); break;
                                case 11: chkHyprtnsn.Items.Add(li); break;
                                case 12: chkHrtDesease.Items.Add(li); break;
                                case 13: chkStroke.Items.Add(li); break;
                                case 14: chkKidneyDisease.Items.Add(li); break;
                                case 15: chkObesity.Items.Add(li); break;
                                case 16: chkGntcDsrdr.Items.Add(li); break;
                                case 17: chkAlchlsm.Items.Add(li); break;
                                case 18: chkLvrDiseas.Items.Add(li); break;
                                case 19: chkDprssn.Items.Add(li); break;
                                case 20: chkClnRctlCncr.Items.Add(li); break;
                                case 21: chkBrstCncr.Items.Add(li); break;
                                case 22: chkOthrCncr.Items.Add(li); break;
                            }
                        }
                    }
                }
                chkDeceased.Items[0].Enabled = false;
            }
        }

        public List<HistoryFamily> HistoryFamilyValues {
            get {
                var v = new List<HistoryFamily>();
                v.AddRange(_CheckBoxValues(chkDeceased));
                v.AddRange(_CheckBoxValues(chkHyprtnsn));
                v.AddRange(_CheckBoxValues(chkHrtDesease));
                v.AddRange(_CheckBoxValues(chkStroke));
                v.AddRange(_CheckBoxValues(chkKidneyDisease));
                v.AddRange(_CheckBoxValues(chkObesity));
                v.AddRange(_CheckBoxValues(chkGntcDsrdr));
                v.AddRange(_CheckBoxValues(chkAlchlsm));
                v.AddRange(_CheckBoxValues(chkLvrDiseas));
                v.AddRange(_CheckBoxValues(chkDprssn));
                v.AddRange(_CheckBoxValues(chkClnRctlCncr));
                v.AddRange(_CheckBoxValues(chkBrstCncr));
                v.AddRange(_CheckBoxValues(chkOthrCncr));
                return v;
            }
            set {
                foreach( HistoryFamily hf in value) {
                    switch (hf.Disease) {
                        case 10: chkDeceased.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 11: chkHyprtnsn.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 12: chkHrtDesease.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 13: chkStroke.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 14: chkKidneyDisease.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 15: chkObesity.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 16: chkGntcDsrdr.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 17: chkAlchlsm.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 18: chkLvrDiseas.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 19: chkDprssn.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 20: chkClnRctlCncr.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 21: chkBrstCncr.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                        case 22: chkOthrCncr.Items.FindByValue(hf.FamilyMember.ToString() + "." + hf.Disease.ToString()).Selected = true; break;
                    }
                }
            }
        }

 

        //public List<HistoryFamily> HistoryFamilyValues() {
        //    var v = new List<HistoryFamily>();

        //    v.AddRange(_CheckBoxValues( chkDeceased));
        //    v.AddRange(_CheckBoxValues( chkHyprtnsn));
        //    v.AddRange(_CheckBoxValues( chkHrtDesease));
        //    v.AddRange(_CheckBoxValues(chkStroke));
        //    v.AddRange(_CheckBoxValues(chkKidneyDisease));
        //    v.AddRange(_CheckBoxValues(chkObesity));
        //    v.AddRange(_CheckBoxValues(chkGntcDsrdr));
        //    v.AddRange(_CheckBoxValues(chkAlchlsm));
        //    v.AddRange(_CheckBoxValues(chkLvrDiseas));
        //    v.AddRange(_CheckBoxValues(chkDprssn));
        //    v.AddRange(_CheckBoxValues(chkClnRctlCncr));
        //    v.AddRange(_CheckBoxValues(chkBrstCncr));
        //    v.AddRange(_CheckBoxValues(chkOthrCncr));

        //    return v;
        //}

        private List<HistoryFamily> _CheckBoxValues( CheckBoxList c) {
            var v = new List<HistoryFamily>();
            foreach ( ListItem li in c.Items) {
                if ( li.Selected) {
                    var fmi = Convert.ToInt16( li.Value.Split('.')[0]);
                    var di = Convert.ToInt16(li.Value.Split('.')[1]);
                    v.Add( new HistoryFamily( fmi, di));
                }
            }
            return v;
        }


        //public bool _value( CheckBoxList c, string v, bool? selected = null) {
        //    if (selected != null) {
        //        c.Items.FindByValue(v).Selected = (bool)selected;
        //        return true;
        //    }
        //    return c.Items.FindByValue(v).Selected;
        //}

            
        //#region DECEASED
        //public bool DeceasedFather {
        //    get { return _value(chkDeceased, "Father"); }
        //    set { _value(chkDeceased, "Father", value); }
        //}

        //public bool DeceasedMother {
        //    get { return _value(chkDeceased, "Mother"); }
        //    set { _value(chkDeceased, "Mother", value); }
        //}

        //public bool DeceasedBrothers {
        //    get { return _value(chkDeceased, "Brothers"); }
        //    set { _value(chkDeceased, "Brothers", value); }
        //}

        //public bool DeceasedSisters {
        //    get { return _value(chkDeceased, "Sisters"); }
        //    set { _value(chkDeceased, "Sisters", value); }
        //}

        //public bool DeceasedUncles {
        //    get { return _value(chkDeceased, "Uncles"); }
        //    set { _value(chkDeceased, "Uncles", value); }
        //}

        //public bool DeceasedAunts {
        //    get { return _value(chkDeceased, "Aunts"); }
        //    set { _value(chkDeceased, "Aunts", value); }
        //}

        //public bool DeceasedDaugthers {
        //    get { return _value(chkDeceased, "Daugthers"); }
        //    set { _value(chkDeceased, "Daugthers", value); }
        //}

        //public bool DeceasedSons {
        //    get { return _value(chkDeceased, "Sons"); }
        //    set { _value(chkDeceased, "Sons", value); }
        //}
        //#endregion


        //#region HYPERTENSION

        //public bool HyprtnsnSelf {
        //    get { return _value(chkHyprtnsn, "Self"); }
        //    set { _value(chkHyprtnsn, "Self", value); }
        //}

        //public bool HyprtnsnFather {
        //    get { return _value(chkHyprtnsn, "Father"); }
        //    set { _value(chkHyprtnsn, "Father", value); }
        //}

        //public bool HyprtnsnMother {
        //    get { return _value(chkHyprtnsn, "Mother"); }
        //    set { _value(chkHyprtnsn, "Mother", value); }
        //}

        //public bool HyprtnsnBrothers {
        //    get { return _value(chkHyprtnsn, "Brothers"); }
        //    set { _value(chkHyprtnsn, "Brothers", value); }
        //}

        //public bool HyprtnsnSisters {
        //    get { return _value(chkHyprtnsn, "Sisters"); }
        //    set { _value(chkHyprtnsn, "Sisters", value); }
        //}

        //public bool HyprtnsnUncles {
        //    get { return _value(chkHyprtnsn, "Uncles"); }
        //    set { _value(chkHyprtnsn, "Uncles", value); }
        //}

        //public bool HyprtnsnAunts {
        //    get { return _value(chkHyprtnsn, "Aunts"); }
        //    set { _value(chkHyprtnsn, "Aunts", value); }
        //}

        //public bool HyprtnsnDaugthers {
        //    get { return _value(chkHyprtnsn, "Daugthers"); }
        //    set { _value(chkHyprtnsn, "Daugthers", value); }
        //}

        //public bool HyprtnsnSons {
        //    get { return _value(chkHyprtnsn, "Sons"); }
        //    set { _value(chkHyprtnsn, "Sons", value); }
        //}
        //#endregion


        //#region HRTDESEASE

        //public bool HrtDeseaseSelf {
        //    get { return _value(chkHrtDesease, "Self"); }
        //    set { _value(chkHrtDesease, "Self", value); }
        //}

        //public bool HrtDeseaseFather {
        //    get { return _value(chkHrtDesease, "Father"); }
        //    set { _value(chkHrtDesease, "Father", value); }
        //}

        //public bool HrtDeseaseMother {
        //    get { return _value(chkHrtDesease, "Mother"); }
        //    set { _value(chkHrtDesease, "Mother", value); }
        //}

        //public bool HrtDeseaseBrothers {
        //    get { return _value(chkHrtDesease, "Brothers"); }
        //    set { _value(chkHrtDesease, "Brothers", value); }
        //}

        //public bool HrtDeseaseSisters {
        //    get { return _value(chkHrtDesease, "Sisters"); }
        //    set { _value(chkHrtDesease, "Sisters", value); }
        //}

        //public bool HrtDeseaseUncles {
        //    get { return _value(chkHrtDesease, "Uncles"); }
        //    set { _value(chkHrtDesease, "Uncles", value); }
        //}

        //public bool HrtDeseaseAunts {
        //    get { return _value(chkHrtDesease, "Aunts"); }
        //    set { _value(chkHrtDesease, "Aunts", value); }
        //}

        //public bool HrtDeseaseDaugthers {
        //    get { return _value(chkHrtDesease, "Daugthers"); }
        //    set { _value(chkHrtDesease, "Daugthers", value); }
        //}

        //public bool HrtDeseaseSons {
        //    get { return _value(chkHrtDesease, "Sons"); }
        //    set { _value(chkHrtDesease, "Sons", value); }
        //}
        //#endregion



        //#region STROKE

        //public bool StrokeSelf {
        //    get { return _value(chkStroke, "Self"); }
        //    set { _value(chkStroke, "Self", value); }
        //}

        //public bool StrokeFather {
        //    get { return _value(chkStroke, "Father"); }
        //    set { _value(chkStroke, "Father", value); }
        //}

        //public bool StrokeMother {
        //    get { return _value(chkStroke, "Mother"); }
        //    set { _value(chkStroke, "Mother", value); }
        //}

        //public bool StrokeBrothers {
        //    get { return _value(chkStroke, "Brothers"); }
        //    set { _value(chkStroke, "Brothers", value); }
        //}

        //public bool StrokeSisters {
        //    get { return _value(chkStroke, "Sisters"); }
        //    set { _value(chkStroke, "Sisters", value); }
        //}

        //public bool StrokeUncles {
        //    get { return _value(chkStroke, "Uncles"); }
        //    set { _value(chkStroke, "Uncles", value); }
        //}

        //public bool StrokeAunts {
        //    get { return _value(chkStroke, "Aunts"); }
        //    set { _value(chkStroke, "Aunts", value); }
        //}

        //public bool StrokeDaugthers {
        //    get { return _value(chkStroke, "Daugthers"); }
        //    set { _value(chkStroke, "Daugthers", value); }
        //}

        //public bool StrokeSons {
        //    get { return _value(chkStroke, "Sons"); }
        //    set { _value(chkStroke, "Sons", value); }
        //}
        //#endregion



        //#region KIDNEY DISEASE

        //public bool KidneyDiseaseSelf {
        //    get { return _value(chkKidneyDisease, "Self"); }
        //    set { _value(chkKidneyDisease, "Self", value); }
        //}

        //public bool KidneyDiseaseFather {
        //    get { return _value(chkKidneyDisease, "Father"); }
        //    set { _value(chkKidneyDisease, "Father", value); }
        //}

        //public bool KidneyDiseaseMother {
        //    get { return _value(chkKidneyDisease, "Mother"); }
        //    set { _value(chkKidneyDisease, "Mother", value); }
        //}

        //public bool KidneyDiseaseBrothers {
        //    get { return _value(chkKidneyDisease, "Brothers"); }
        //    set { _value(chkKidneyDisease, "Brothers", value); }
        //}

        //public bool KidneyDiseaseSisters {
        //    get { return _value(chkKidneyDisease, "Sisters"); }
        //    set { _value(chkKidneyDisease, "Sisters", value); }
        //}

        //public bool KidneyDiseaseUncles {
        //    get { return _value(chkKidneyDisease, "Uncles"); }
        //    set { _value(chkKidneyDisease, "Uncles", value); }
        //}

        //public bool KidneyDiseaseAunts {
        //    get { return _value(chkKidneyDisease, "Aunts"); }
        //    set { _value(chkKidneyDisease, "Aunts", value); }
        //}

        //public bool KidneyDiseaseDaugthers {
        //    get { return _value(chkKidneyDisease, "Daugthers"); }
        //    set { _value(chkKidneyDisease, "Daugthers", value); }
        //}

        //public bool KidneyDiseaseSons {
        //    get { return _value(chkKidneyDisease, "Sons"); }
        //    set { _value(chkKidneyDisease, "Sons", value); }
        //}
        //#endregion



        //#region OBESITY

        //public bool ObesitySelf {
        //    get { return _value(chkObesity, "Self"); }
        //    set { _value(chkObesity, "Self", value); }
        //}

        //public bool ObesityFather {
        //    get { return _value(chkObesity, "Father"); }
        //    set { _value(chkObesity, "Father", value); }
        //}

        //public bool ObesityMother {
        //    get { return _value(chkObesity, "Mother"); }
        //    set { _value(chkObesity, "Mother", value); }
        //}

        //public bool ObesityBrothers {
        //    get { return _value(chkObesity, "Brothers"); }
        //    set { _value(chkObesity, "Brothers", value); }
        //}

        //public bool ObesitySisters {
        //    get { return _value(chkObesity, "Sisters"); }
        //    set { _value(chkObesity, "Sisters", value); }
        //}

        //public bool ObesityUncles {
        //    get { return _value(chkObesity, "Uncles"); }
        //    set { _value(chkObesity, "Uncles", value); }
        //}

        //public bool ObesityAunts {
        //    get { return _value(chkObesity, "Aunts"); }
        //    set { _value(chkObesity, "Aunts", value); }
        //}

        //public bool ObesityDaugthers {
        //    get { return _value(chkObesity, "Daugthers"); }
        //    set { _value(chkObesity, "Daugthers", value); }
        //}

        //public bool ObesitySons {
        //    get { return _value(chkObesity, "Sons"); }
        //    set { _value(chkObesity, "Sons", value); }
        //}
        //#endregion



        //#region GNTCDSRDR

        //public bool GntcDsrdrSelf {
        //    get { return _value(chkGntcDsrdr, "Self"); }
        //    set { _value(chkGntcDsrdr, "Self", value); }
        //}

        //public bool GntcDsrdrFather {
        //    get { return _value(chkGntcDsrdr, "Father"); }
        //    set { _value(chkGntcDsrdr, "Father", value); }
        //}

        //public bool GntcDsrdrMother {
        //    get { return _value(chkGntcDsrdr, "Mother"); }
        //    set { _value(chkGntcDsrdr, "Mother", value); }
        //}

        //public bool GntcDsrdrBrothers {
        //    get { return _value(chkGntcDsrdr, "Brothers"); }
        //    set { _value(chkGntcDsrdr, "Brothers", value); }
        //}

        //public bool GntcDsrdrSisters {
        //    get { return _value(chkGntcDsrdr, "Sisters"); }
        //    set { _value(chkGntcDsrdr, "Sisters", value); }
        //}

        //public bool GntcDsrdrUncles {
        //    get { return _value(chkGntcDsrdr, "Uncles"); }
        //    set { _value(chkGntcDsrdr, "Uncles", value); }
        //}

        //public bool GntcDsrdrAunts {
        //    get { return _value(chkGntcDsrdr, "Aunts"); }
        //    set { _value(chkGntcDsrdr, "Aunts", value); }
        //}

        //public bool GntcDsrdrDaugthers {
        //    get { return _value(chkGntcDsrdr, "Daugthers"); }
        //    set { _value(chkGntcDsrdr, "Daugthers", value); }
        //}

        //public bool GntcDsrdrSons {
        //    get { return _value(chkGntcDsrdr, "Sons"); }
        //    set { _value(chkGntcDsrdr, "Sons", value); }
        //}
        //#endregion



        //#region ALCHLSM

        //public bool AlchlsmSelf {
        //    get { return _value(chkAlchlsm, "Self"); }
        //    set { _value(chkAlchlsm, "Self", value); }
        //}

        //public bool AlchlsmFather {
        //    get { return _value(chkAlchlsm, "Father"); }
        //    set { _value(chkAlchlsm, "Father", value); }
        //}

        //public bool AlchlsmMother {
        //    get { return _value(chkAlchlsm, "Mother"); }
        //    set { _value(chkAlchlsm, "Mother", value); }
        //}

        //public bool AlchlsmBrothers {
        //    get { return _value(chkAlchlsm, "Brothers"); }
        //    set { _value(chkAlchlsm, "Brothers", value); }
        //}

        //public bool AlchlsmSisters {
        //    get { return _value(chkAlchlsm, "Sisters"); }
        //    set { _value(chkAlchlsm, "Sisters", value); }
        //}

        //public bool AlchlsmUncles {
        //    get { return _value(chkAlchlsm, "Uncles"); }
        //    set { _value(chkAlchlsm, "Uncles", value); }
        //}

        //public bool AlchlsmAunts {
        //    get { return _value(chkAlchlsm, "Aunts"); }
        //    set { _value(chkAlchlsm, "Aunts", value); }
        //}

        //public bool AlchlsmDaugthers {
        //    get { return _value(chkAlchlsm, "Daugthers"); }
        //    set { _value(chkAlchlsm, "Daugthers", value); }
        //}

        //public bool AlchlsmSons {
        //    get { return _value(chkAlchlsm, "Sons"); }
        //    set { _value(chkAlchlsm, "Sons", value); }
        //}
        //#endregion



        //#region LVRDISEAS

        //public bool LvrDiseasSelf {
        //    get { return _value(chkLvrDiseas, "Self"); }
        //    set { _value(chkLvrDiseas, "Self", value); }
        //}

        //public bool LvrDiseasFather {
        //    get { return _value(chkLvrDiseas, "Father"); }
        //    set { _value(chkLvrDiseas, "Father", value); }
        //}

        //public bool LvrDiseasMother {
        //    get { return _value(chkLvrDiseas, "Mother"); }
        //    set { _value(chkLvrDiseas, "Mother", value); }
        //}

        //public bool LvrDiseasBrothers {
        //    get { return _value(chkLvrDiseas, "Brothers"); }
        //    set { _value(chkLvrDiseas, "Brothers", value); }
        //}

        //public bool LvrDiseasSisters {
        //    get { return _value(chkLvrDiseas, "Sisters"); }
        //    set { _value(chkLvrDiseas, "Sisters", value); }
        //}

        //public bool LvrDiseasUncles {
        //    get { return _value(chkLvrDiseas, "Uncles"); }
        //    set { _value(chkLvrDiseas, "Uncles", value); }
        //}

        //public bool LvrDiseasAunts {
        //    get { return _value(chkLvrDiseas, "Aunts"); }
        //    set { _value(chkLvrDiseas, "Aunts", value); }
        //}

        //public bool LvrDiseasDaugthers {
        //    get { return _value(chkLvrDiseas, "Daugthers"); }
        //    set { _value(chkLvrDiseas, "Daugthers", value); }
        //}

        //public bool LvrDiseasSons {
        //    get { return _value(chkLvrDiseas, "Sons"); }
        //    set { _value(chkLvrDiseas, "Sons", value); }
        //}
        //#endregion



        //#region DPRSSN

        //public bool DprssnSelf {
        //    get { return _value(chkDprssn, "Self"); }
        //    set { _value(chkDprssn, "Self", value); }
        //}

        //public bool DprssnFather {
        //    get { return _value(chkDprssn, "Father"); }
        //    set { _value(chkDprssn, "Father", value); }
        //}

        //public bool DprssnMother {
        //    get { return _value(chkDprssn, "Mother"); }
        //    set { _value(chkDprssn, "Mother", value); }
        //}

        //public bool DprssnBrothers {
        //    get { return _value(chkDprssn, "Brothers"); }
        //    set { _value(chkDprssn, "Brothers", value); }
        //}

        //public bool DprssnSisters {
        //    get { return _value(chkDprssn, "Sisters"); }
        //    set { _value(chkDprssn, "Sisters", value); }
        //}

        //public bool DprssnUncles {
        //    get { return _value(chkDprssn, "Uncles"); }
        //    set { _value(chkDprssn, "Uncles", value); }
        //}

        //public bool DprssnAunts {
        //    get { return _value(chkDprssn, "Aunts"); }
        //    set { _value(chkDprssn, "Aunts", value); }
        //}

        //public bool DprssnDaugthers {
        //    get { return _value(chkDprssn, "Daugthers"); }
        //    set { _value(chkDprssn, "Daugthers", value); }
        //}

        //public bool DprssnSons {
        //    get { return _value(chkDprssn, "Sons"); }
        //    set { _value(chkDprssn, "Sons", value); }
        //}
        //#endregion



        //#region CLNRCTLCNCR

        //public bool ClnRctlCncrSelf {
        //    get { return _value(chkClnRctlCncr, "Self"); }
        //    set { _value(chkClnRctlCncr, "Self", value); }
        //}

        //public bool ClnRctlCncrFather {
        //    get { return _value(chkClnRctlCncr, "Father"); }
        //    set { _value(chkClnRctlCncr, "Father", value); }
        //}

        //public bool ClnRctlCncrMother {
        //    get { return _value(chkClnRctlCncr, "Mother"); }
        //    set { _value(chkClnRctlCncr, "Mother", value); }
        //}

        //public bool ClnRctlCncrBrothers {
        //    get { return _value(chkClnRctlCncr, "Brothers"); }
        //    set { _value(chkClnRctlCncr, "Brothers", value); }
        //}

        //public bool ClnRctlCncrSisters {
        //    get { return _value(chkClnRctlCncr, "Sisters"); }
        //    set { _value(chkClnRctlCncr, "Sisters", value); }
        //}

        //public bool ClnRctlCncrUncles {
        //    get { return _value(chkClnRctlCncr, "Uncles"); }
        //    set { _value(chkClnRctlCncr, "Uncles", value); }
        //}

        //public bool ClnRctlCncrAunts {
        //    get { return _value(chkClnRctlCncr, "Aunts"); }
        //    set { _value(chkClnRctlCncr, "Aunts", value); }
        //}

        //public bool ClnRctlCncrDaugthers {
        //    get { return _value(chkClnRctlCncr, "Daugthers"); }
        //    set { _value(chkClnRctlCncr, "Daugthers", value); }
        //}

        //public bool ClnRctlCncrSons {
        //    get { return _value(chkClnRctlCncr, "Sons"); }
        //    set { _value(chkClnRctlCncr, "Sons", value); }
        //}
        //#endregion



        //#region BRSTCNCR

        //public bool BrstCncrSelf {
        //    get { return _value(chkBrstCncr, "Self"); }
        //    set { _value(chkBrstCncr, "Self", value); }
        //}

        //public bool BrstCncrFather {
        //    get { return _value(chkBrstCncr, "Father"); }
        //    set { _value(chkBrstCncr, "Father", value); }
        //}

        //public bool BrstCncrMother {
        //    get { return _value(chkBrstCncr, "Mother"); }
        //    set { _value(chkBrstCncr, "Mother", value); }
        //}

        //public bool BrstCncrBrothers {
        //    get { return _value(chkBrstCncr, "Brothers"); }
        //    set { _value(chkBrstCncr, "Brothers", value); }
        //}

        //public bool BrstCncrSisters {
        //    get { return _value(chkBrstCncr, "Sisters"); }
        //    set { _value(chkBrstCncr, "Sisters", value); }
        //}

        //public bool BrstCncrUncles {
        //    get { return _value(chkBrstCncr, "Uncles"); }
        //    set { _value(chkBrstCncr, "Uncles", value); }
        //}

        //public bool BrstCncrAunts {
        //    get { return _value(chkBrstCncr, "Aunts"); }
        //    set { _value(chkBrstCncr, "Aunts", value); }
        //}

        //public bool BrstCncrDaugthers {
        //    get { return _value(chkBrstCncr, "Daugthers"); }
        //    set { _value(chkBrstCncr, "Daugthers", value); }
        //}

        //public bool BrstCncrSons {
        //    get { return _value(chkBrstCncr, "Sons"); }
        //    set { _value(chkBrstCncr, "Sons", value); }
        //}
        //#endregion



        //#region OTHRCNCR

        //public bool OthrCncrSelf {
        //    get { return _value(chkOthrCncr, "Self"); }
        //    set { _value(chkOthrCncr, "Self", value); }
        //}

        //public bool OthrCncrFather {
        //    get { return _value(chkOthrCncr, "Father"); }
        //    set { _value(chkOthrCncr, "Father", value); }
        //}

        //public bool OthrCncrMother {
        //    get { return _value(chkOthrCncr, "Mother"); }
        //    set { _value(chkOthrCncr, "Mother", value); }
        //}

        //public bool OthrCncrBrothers {
        //    get { return _value(chkOthrCncr, "Brothers"); }
        //    set { _value(chkOthrCncr, "Brothers", value); }
        //}

        //public bool OthrCncrSisters {
        //    get { return _value(chkOthrCncr, "Sisters"); }
        //    set { _value(chkOthrCncr, "Sisters", value); }
        //}

        //public bool OthrCncrUncles {
        //    get { return _value(chkOthrCncr, "Uncles"); }
        //    set { _value(chkOthrCncr, "Uncles", value); }
        //}

        //public bool OthrCncrAunts {
        //    get { return _value(chkOthrCncr, "Aunts"); }
        //    set { _value(chkOthrCncr, "Aunts", value); }
        //}

        //public bool OthrCncrDaugthers {
        //    get { return _value(chkOthrCncr, "Daugthers"); }
        //    set { _value(chkOthrCncr, "Daugthers", value); }
        //}

        //public bool OthrCncrSons {
        //    get { return _value(chkOthrCncr, "Sons"); }
        //    set { _value(chkOthrCncr, "Sons", value); }
        //}
        //#endregion




    }
}