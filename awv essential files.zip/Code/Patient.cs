﻿using System;
using System.Collections.Generic;

namespace awv {

    public class Patient : PatientBase {

        public int Add( Patient p) {
            if ( string.IsNullOrEmpty(p.LName) && string.IsNullOrEmpty( p.FName)) { return -1; }
            return new db().AddPatient(p);
        }

        public Patient Get(int id) {
            return new db().GetPatient(id);
        }

        public string GetPdfReport( int id) {
            return new db().GetPatient( id).ToString();
        }

        public List<PatientBase> GetAll() {
            return new db().GetAllPatients();
        }

        internal int SaveDemographic( PatientBase pb) {
            return new db().SavePatientBase(pb);
        }

        internal bool SaveVitals( Patient v) {
            return new db().UpdateVitals(v);
        }

        public bool SaveHistoryFamily( int patientId, List<HistoryFamily> hf) {
            new db().UpdateHistoryFamily( patientId, hf);
            return true;
        }

        internal bool SaveHistorySocial( int patientId, HistorySocial hs) {
            return new db().UpdateHistorySocial( patientId, hs);
        }

        internal bool SaveScreeningDprssn( int patientId, int depressed, int littleInterest) {
            bool? _depressed = null;
            if ( !depressed.Equals(-1)) {
                _depressed = depressed.Equals(0) ? false : true;
            }
            bool? _littleInterest = null;
            if (!littleInterest.Equals(-1)) {
                _littleInterest = littleInterest.Equals(0) ? false : true;
            }
            return new db().UpdateScreeningDprssn( patientId, _depressed, _littleInterest);
        }

        internal bool SaveScreeningFnctn( int patientId, int unsteady, int livesAlon, int needHlpWithMeals) {
            bool? _unsteady = null;
            if ( !unsteady.Equals(-1)) {
                _unsteady = unsteady.Equals(0) ? false : true;
            }
            bool? _livesAlon = null;
            if (!livesAlon.Equals(-1)) {
                _livesAlon = livesAlon.Equals(0) ? false : true;
            }
            bool? _needHlpWithMeals = null;
            if (!needHlpWithMeals.Equals(-1))
            {
                _needHlpWithMeals = needHlpWithMeals.Equals(0) ? false : true;
            }
            return new db().UpdateScreeningFnctn( patientId, _unsteady, _livesAlon, _needHlpWithMeals);
        }

        internal bool SaveScreeningMiniCog( 
                int patientId, 
                int? WordListVersion, int? AnswerA, int? AnswerB, int? AnswerC, 
                int? ScoringWordRecall, int? ScoringClockDraw) {
            return new db().UpdateScreeningMinCog( 
                    patientId, 
                    WordListVersion, 
                    AnswerA, 
                    AnswerB, 
                    AnswerC, 
                    ScoringWordRecall, 
                    ScoringClockDraw);
        }

        internal bool SaveScreeningHrngLss( int patientId, int hearngDffclts, int strainHearng) {
            bool? _hearngDffclts = null;
            if ( !hearngDffclts.Equals(-1)) {
                _hearngDffclts = hearngDffclts.Equals(0) ? false : true;
            }
            bool? _strainHearng = null;
            if (!strainHearng.Equals(-1)) {
                _strainHearng = strainHearng.Equals(0) ? false : true;
            }
            return new db().UpdateScreeningHrngLss( patientId, _hearngDffclts, _strainHearng);
        }


        internal bool SaveScreeningHmSft( int patientId, int rugs, int lackGrabBars) {
            bool? _rugs = null;
            if ( !rugs.Equals(-1)) {
                _rugs = rugs.Equals(0) ? false : true;
            }
            bool? _lackGrabBars = null;
            if (!lackGrabBars.Equals(-1)) {
                _lackGrabBars = lackGrabBars.Equals(0) ? false : true;
            }
            return new db().UpdateScreeningHmSft( patientId, _rugs, _lackGrabBars);
        }

        internal bool SavePreventive(int patientId, Preventive p) {
            return new db().UpdatePreventive(patientId, p);
        }


        public List<HospitalVisit> GetHospitalVisits( int patientId) {
            var hvL = new List<HospitalVisit>();
            hvL.Add( new HospitalVisit( "some reason", "some facility", "some physician", new  DateTime (2017, 1,1)));
            hvL.Add( new HospitalVisit( "another reason", "another facility", "another physician", new DateTime(2010, 1, 1)));
            return hvL;
        }

        public bool Delete( int patientId) {
            ///todo - call db
            return true;
        }

        #region PUBLIC PROPERTIES

        public double? HeightInCM { get; set; }

        public double? Weight { get; set; }

        public double? BMI { get; set; }

        public double? Waist { get; set; }

        public BloodPressure BloodPressure { get; set; }

        public double? Temp { get; set; }

        public HistorySocial HistorySocial { get; set; }

        public List<HistoryFamily> HistoryFamily { get; set; }

        public Medical Medical { get; set; }

        public Screening Screening { get; set; }

        internal bool AddHospitalVisit(int patientId, string reason, string facility, string physician, DateTime? visitDate = null) {
            return new db().AddHospitalVisit( patientId, reason, facility, physician, visitDate);
        }

        
        internal bool AddAllergy(int patientId, string allergy, string reaction) {
            return new db().AddAllergy( patientId, allergy, reaction);
        }

        internal bool AddProvider(int patientId, string providerNameAndSpecialty, string typeofCare, DateTime? endDate = null) {
            return new db().AddProvider( patientId, providerNameAndSpecialty, typeofCare, endDate);
        }

        #endregion


    }


}